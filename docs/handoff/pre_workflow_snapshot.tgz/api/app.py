"""
CvSU Chatbot REST API
FastAPI-based endpoint for integration with web applications
"""

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from enum import Enum
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from typing import Annotated, Optional, List, Dict, Any, Literal, Union
import asyncio
import json
import os
import random
import re
import ipaddress
import secrets
import time
import sys
import functools
from concurrent.futures import ThreadPoolExecutor
from collections import defaultdict, deque
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit

import joblib
import nltk
from nltk.stem import WordNetLemmatizer

# Import logger
from .logger import ChatLogger, is_safe_user_id as _is_safe_user_id
# Import hybrid chatbot
from .hybrid_chatbot import HybridChatbot, REPLY_LANGUAGES
# The module itself, not just the class: the startup warm-up touches its
# module-level NLTK lemmatizer (see _warm_lazy_singletons).
from . import hybrid_chatbot as _hybrid_chatbot
from . import intent_retrieval as _intent_retrieval
from . import site_rag as _site_rag
# Seasonal topic recommender + intent-onboarding sanitation checks
from .topic_recommender import recommend as _recommend_topics
from .intent_curation import sanitize_candidate_intent as _sanitize_candidate_intent
from .intent_curation import is_reserved_tag as _intent_curation_is_reserved
# AIS MCP bridge — routes finance queries to the CvSU AIS MCP server
from .ais_mcp import try_handle as _try_ais
from .ais_mcp import metrics_snapshot as _ais_metrics_snapshot
from .ais_mcp import close_pool as _ais_close_pool
from .ais_mcp import call_tool as _ais_call_tool
from .ais_mcp import ToolCallError as _AisToolCallError
from .ais_mcp import _sanitize_tool_error as _ais_sanitize_tool_error
from .connectors_mcp import try_handle as _try_connectors
from .hr_mcp import try_handle as _try_hr
from .connectors_mcp import metrics_snapshot as _connectors_metrics_snapshot
from .ais_mcp import circuit_status as _ais_circuit_status
from . import safety as _safety
from . import anti_patterns as _anti_patterns
from . import workflows as _workflows
from . import campus_context as _campus
from . import campus_directory as _campus_directory
from . import charter_rag as _charter_rag
from . import charter_pages as _charter_pages
from . import intent_grounding as _intent_grounding
from .response_blocks import ContentBlock, NOTE_PREFIX_RE, parse_blocks as _parse_blocks
# Phase 2A Wave 2 — per-user AIS authentication for write actions.
from . import auth_ais as _ais_auth

import logging as _logging
_logger = _logging.getLogger("diwa.api")

# ── In-container log tail ────────────────────────────────────────────────────
# Recent log lines kept in memory and served by GET /admin/logs, so deployments
# where `docker logs` isn't reachable (the test server) can still read the
# diagnostics that explain a failure — e.g. the "[4/5] LLM fallback" init lines
# and per-turn tier decisions. Captures BOTH logging records and print() output.
# Bounded ring buffer; cleared on restart; fine under --workers 1.
_LOG_TAIL: deque = deque(maxlen=int(os.getenv("LOG_TAIL_LINES", "2000")))
_LOG_TS = "%Y-%m-%d %H:%M:%S"


class _LogTailHandler(_logging.Handler):
    """Copy every logging record into the in-memory tail."""

    def emit(self, record):
        try:
            _LOG_TAIL.append(self.format(record))
        except Exception:
            pass  # diagnostics must never break the request path


_tail_fmt = _logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s", _LOG_TS)
_tail_handler = _LogTailHandler()
_tail_handler.setFormatter(_tail_fmt)
# Root gets the tail plus an explicit stderr handler: without one, Python's
# last-resort handler drops INFO records entirely (and adding only the tail
# would steal WARNINGs from docker logs). INFO now reaches both destinations.
_stderr_handler = _logging.StreamHandler()
_stderr_handler.setFormatter(_tail_fmt)
_logging.getLogger().addHandler(_tail_handler)
_logging.getLogger().addHandler(_stderr_handler)
_logging.getLogger().setLevel(_logging.INFO)
# uvicorn's loggers don't propagate to root — tap uvicorn.error explicitly
# (skip uvicorn.access: polling /admin/logs would fill the tail with itself).
_logging.getLogger("uvicorn.error").addHandler(_tail_handler)


class _StdoutTee:
    """Pass-through stdout wrapper that copies print() lines into the tail.

    stdout ONLY — logging handlers write to stderr, so teeing stderr would
    double-capture every record. The chatbot's diagnostics are print()s."""

    def __init__(self, stream):
        self._stream = stream

    def write(self, text):
        self._stream.write(text)
        for line in text.splitlines():
            if line.strip():
                _LOG_TAIL.append(f"{time.strftime(_LOG_TS)} STDOUT: {line}")

    def flush(self):
        self._stream.flush()

    def __getattr__(self, name):
        return getattr(self._stream, name)


sys.stdout = _StdoutTee(sys.stdout)

# Download NLTK resources (idempotent — no-op if already present)
for resource, kind in [('punkt_tab', 'tokenizers'), ('wordnet', 'corpora')]:
    try:
        nltk.data.find(f'{kind}/{resource}')
    except (LookupError, OSError):
        nltk.download(resource, quiet=True)

lemmatizer = WordNetLemmatizer()

# ============================================================================
# SYSTEM INSTRUCTIONS / AGENT PERSONALITY
# ============================================================================
SYSTEM_INSTRUCTIONS = """
You are Sevi, the virtual assistant for Cavite State University - a helpful, friendly guide.

1. IDENTITY AND SCOPE
- You serve prospective students, current students, parents, faculty, and the general public.
- You cover academic programs, admissions, campus services, scholarships, fees, schedules, policies, and general information about CvSU's main campus in Indang and its satellite campuses (Imus, Rosario, Silang, Naic, Trece Martires, Tanza, General Trias, Carmona, Cavite City, Bacoor, and others).
- You do NOT process enrollment, payments, or official document requests. Always redirect high-stakes actions (enrollment, grade disputes, document authentication) to the proper office.

2. CORE PERSONALITY
- Professional yet approachable; warm and respectful of Filipino culture ("Iskolar para sa Bayan").
- Patient and empathetic - many users are first-generation applicants or parents unfamiliar with university processes. Avoid jargon without explanation.
- Proactive in offering next steps and pointing to verification.

3. RETRIEVAL AND VERIFICATION PROTOCOL
Before answering a factual question:
- Classify the query: (a) general/stable, (b) time-sensitive, (c) campus-specific, (d) personal/transactional.
- Time-sensitive items (deadlines, fees, schedules, CvSUAT dates) must be flagged for verification with the relevant office. Qualify with "as of [date], please verify with [office]."
- For any specific number, date, name, or requirement, cite the source or qualify clearly.
- Disambiguate campus before giving program-specific or fee-specific answers - CvSU Indang and CvSU Imus may have very different offerings.

4. CONFIDENCE TIERS - never blur these
- High confidence: from official, recently verified CvSU sources. State plainly.
- Medium confidence: from official sources but possibly outdated. State with date qualifier and recommend verification.
- Low confidence: from secondary sources, inference, or older data. State as such and direct the user to the relevant office.
- No information: admit the gap honestly. Never fabricate. Provide the contact path of who would know.

5. DISAMBIGUATION
When a query is ambiguous, ask one targeted clarifying question, e.g.:
- "CvSU has multiple campuses. Which one are you asking about?"
- "Are you asking as a freshman applicant, transferee, or graduate student?"
- "Which academic year - 2025-2026 or 2026-2027?"
Limit to one clarifying question per turn unless absolutely necessary.

6. RESPONSE STRUCTURE
- Direct answer first, supporting details second, caveats and verification reminders last.
- Include contact info for the specific office when relevant.
- Short answers for simple lookups; longer structured answers for process questions.
- Offer next steps: "Is there anything else I can help you with?"

7. LANGUAGE
- Primary: English (professional). Respond in the language the user uses; if they mix Tagalog and English (Taglish), respond in kind.
- Use formal Filipino academic terminology when discussing official terms (e.g., "Pagsusulit sa Pagpasok," "Rehistrar").

8. PRIVACY AND DATA HANDLING (RA 10173)
- Never request or store personal information (full name, student number, contact details) unless the platform explicitly supports secure data handling.
- Never speculate about specific students' grades, status, or records.
- Redirect all individual student inquiries to the registrar or guidance office.

9. ESCALATION PATHWAYS - surface the right office
- Admissions questions -> Office of Admissions, specific campus
- Enrollment issues -> Registrar, specific campus
- Financial concerns -> Cashier and Scholarship Office (note RA 10931 free higher education subsidy where applicable)
- Academic concerns -> department chair or college dean
- Student welfare -> Office of Student Affairs and Services (OSAS)
- Online system issues -> Management Information Systems (MIS) office
- Complaints/appeals -> Campus Administrator or University President's Office

10. REFUSAL AND REDIRECTION
Decline to:
- Predict admission outcomes for specific applicants.
- Compare CvSU unfavorably to other institutions in misleading ways.
- Give legal interpretations of university policies (refer to the official policy documents).
- Provide unofficial workarounds to academic requirements.
- Share contact details of individual faculty without official verification.

11. PROHIBITED
- Do NOT fabricate tuition figures, professor names, deadlines, course codes, or passing rates.
- Do NOT promise services beyond CvSU's scope.
- Do NOT provide personal opinions on university policies.
- Do NOT give a generic "CvSU" answer without first asking which campus when the campus matters.

12. META
You are a helpful starting point and information aggregator, not the final authority. For anything consequential - enrollment, scholarships, document requirements - empower the user to verify with the proper CvSU office, and provide the path to that verification.
"""

# ============================================================================
# FastAPI Application
# ============================================================================
_is_production = os.getenv("RENDER", "") != "" or os.getenv("PRODUCTION", "") != ""


# Closes the cached AIS MCP session when uvicorn shuts down so we don't
# leak the SSE stream + transport. Open is lazy on first use; close is
# eager here.
from contextlib import asynccontextmanager  # noqa: E402

async def _retention_loop(days: int):
    """Enforce the log-retention window (docs/privacy_compliance.md §2): purge
    chat rows older than `days`, once at startup and every 24h after. The
    blocking DELETE runs off the event loop; failures are logged, never fatal.
    LOG_RETENTION_DAYS=0 disables the sweep entirely."""
    while True:
        try:
            deleted = await asyncio.to_thread(chat_logger.cleanup_old_logs, days)
            if deleted:
                _logger.info("retention sweep: purged %d chat rows older than %dd", deleted, days)
        except Exception:  # noqa: BLE001 — retention must never take the app down
            _logger.warning("retention sweep failed", exc_info=False)
        await asyncio.sleep(24 * 3600)


async def _corpus_sync_loop(hours: float):
    """Re-mirror the official site every `hours` and rebuild the RAG index.

    Without this the corpus only refreshes when an admin posts to
    /admin/site_corpus/sync, so the mirror drifts from the portal silently.
    SITE_CORPUS_SYNC_HOURS=0 (the default) disables it.

    Two things this deliberately does NOT do. It never syncs at startup — a
    portal outage during a deploy would otherwise rewrite the corpus on every
    restart; the first sync lands one interval in. And it never lets a failure
    propagate: sync_corpus raises rather than truncate, so on error the last
    good corpus simply stays in place.

    NOTE: freshness here is mirror freshness only. Several official program
    pages have not been edited upstream in years (CEIT's is from 2018), so
    syncing nightly re-fetches the same old page. Answers must carry the
    source's own date rather than imply currency this loop cannot provide.
    """
    interval = max(hours, 1.0) * 3600
    while True:
        await asyncio.sleep(interval)
        try:
            stats = await asyncio.to_thread(_site_rag.sync_corpus)
            await asyncio.to_thread(_site_rag.reload_index)
            _logger.info(
                "site corpus sync: %d docs, %d skipped -> %s",
                stats.get("docs", 0), stats.get("skipped", 0), stats.get("path"),
            )
        except Exception:  # noqa: BLE001 — a dead portal must never take the app down
            _logger.warning("site corpus sync failed; keeping the existing corpus",
                            exc_info=False)


def _warm_lazy_singletons() -> None:
    """Materialize the retrieval indexes and NLTK's lazy loaders before traffic.

    Every one of these is a check-then-set singleton that today first builds
    inside a chat worker thread. While a single global lock serialized every
    chat turn that was safe by accident — only one thread could ever be in the
    build. Once turns run concurrently, the first burst after a restart fans N
    threads into the same unguarded `if _index is None` (see site_rag.get_index),
    each constructing its own index inside a 2G container.

    Warming here closes the window rather than reasoning about it. Nothing in
    this function may raise: a cold index degrades an answer, a failed boot
    takes the service down.
    """
    started = time.time()
    for name, get_index in (
        ("charter_rag", _charter_rag.get_index),
        # Built on the chat path by every charter citation, so it has the same
        # first-burst race as the retrieval indexes.
        ("charter_pages", _charter_pages.get_index),
        ("site_rag", _site_rag.get_index),
        ("intent_retrieval", _intent_retrieval.get_index),
        ("intent_grounding", _intent_grounding.get_index),
    ):
        try:
            get_index()
        except Exception:  # noqa: BLE001 — a cold index must never block boot
            _logger.warning("warm-up: %s index failed to build", name, exc_info=False)

    # WordNetLemmatizer is constructed at hybrid_chatbot import but never
    # called, so the WordNet corpus behind it is still an unloaded
    # LazyCorpusLoader — and that first load is the known NLTK thread race.
    # Both helpers run on every turn (hybrid_chatbot._preprocess), so touching
    # them once here is enough.
    try:
        _hybrid_chatbot.lemmatizer.lemmatize("tests")
        nltk.word_tokenize("warm up")
    except Exception:  # noqa: BLE001
        _logger.warning("warm-up: NLTK lazy loaders failed", exc_info=False)

    _logger.info("warm-up finished in %.1fs", time.time() - started)


@asynccontextmanager
async def _lifespan(_app: FastAPI):
    tasks = []

    # Size the default thread pool explicitly. asyncio.to_thread uses the
    # loop's default executor, which is sized min(32, os.cpu_count() + 4) — and
    # under Docker `cpus: '2.0'` is a CFS quota, not a cpuset, so os.cpu_count()
    # reports the HOST's core count. The default is therefore both unpredictable
    # across machines and unrelated to the container's actual CPU budget.
    # Headroom over the turn limit matters: index reloads, admin snapshots and
    # the retention sweep all borrow from this pool, and a pool sized at exactly
    # _TURN_LIMIT would let in-flight turns starve them.
    _executor = ThreadPoolExecutor(
        max_workers=_TURN_LIMIT + 8, thread_name_prefix="sevi",
    )
    asyncio.get_running_loop().set_default_executor(_executor)
    _logger.info(
        "turn gate: %d concurrent, %d queued, %.0fs queue timeout; worker pool %d",
        _TURN_LIMIT, _TURN_QUEUE_MAX, _TURN_QUEUE_TIMEOUT, _TURN_LIMIT + 8,
    )

    # Off the event loop: these are blocking disk reads and TF-IDF builds, and
    # /health must stay answerable while they run (compose gives the container
    # a 30s start_period before the healthcheck counts against it).
    await asyncio.to_thread(_warm_lazy_singletons)

    # The per-IP tier is the only chat limit a client cannot rotate, but it can
    # only see a real client address when a trusted proxy header is configured.
    # Left unset, _client_ip falls back to the peer address — which behind a
    # reverse proxy is ONE address for every user, quietly turning a per-client
    # limit into a single global ceiling. Too easy to miss to stay silent.
    if not _CLIENT_IP_HEADER:
        _logger.warning(
            "TRUSTED_CLIENT_IP_HEADER is unset — per-IP chat throttling keys on "
            "the peer address. Behind a reverse proxy that is one address for "
            "ALL traffic, so CHAT_RATE_LIMIT_IP_MAX (%d per %.0fs) acts as a "
            "server-wide ceiling, not a per-client limit.",
            _CHAT_IP_MAX_REQUESTS, _CHAT_WINDOW_SECONDS,
        )

    retention_days = int(os.getenv("LOG_RETENTION_DAYS", "365"))
    if retention_days > 0:
        tasks.append(asyncio.create_task(_retention_loop(retention_days)))

    sync_hours = float(os.getenv("SITE_CORPUS_SYNC_HOURS", "0") or 0)
    if sync_hours > 0 and os.getenv("SITE_CORPUS_URL"):
        tasks.append(asyncio.create_task(_corpus_sync_loop(sync_hours)))
        _logger.info("site corpus auto-sync every %.1fh", max(sync_hours, 1.0))
    elif sync_hours > 0:
        _logger.warning("SITE_CORPUS_SYNC_HOURS is set but SITE_CORPUS_URL is not "
                        "— auto-sync disabled")
    try:
        yield
    finally:
        for task in tasks:
            task.cancel()
        for task in tasks:
            try:
                await task
            except asyncio.CancelledError:
                pass
        await _ais_close_pool()
        # Let queued log writes finish before the process goes away — losing an
        # audit row on shutdown is avoidable. The turn pool is drained without
        # waiting: anything still in it is a turn whose client is already gone.
        _log_pool.shutdown(wait=True)
        _executor.shutdown(wait=False)


# Deployed version, set by compose (SEVI_VERSION in the api service's
# environment) and surfaced at /health so you can confirm from a browser which
# build a server is actually running — the failure this closes is a deploy that
# reports healthy while still serving the previous image. `dev` means the
# variable was never set, i.e. a local run or a compose file that predates it.
# SEVI_BUILD carries the commit SHA when CI injects it.
APP_VERSION = os.getenv("SEVI_VERSION", "dev").strip() or "dev"
APP_BUILD = os.getenv("SEVI_BUILD", "").strip()

app = FastAPI(
    title="DIWA API",
    version=APP_VERSION,
    docs_url=None if _is_production else "/docs",
    redoc_url=None if _is_production else "/redoc",
    openapi_url=None if _is_production else "/openapi.json",
    lifespan=_lifespan,
)

# Enable CORS — explicit origins only (never wildcard in production).
# Default to localhost dev server; override via CORS_ORIGINS env var.
_cors_origins = os.getenv("CORS_ORIGINS", "http://localhost:5173")
_allowed_origins = [o.strip() for o in _cors_origins.split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "X-Admin-Pin", "X-Sevi-Session"],
)

# ============================================================================
# Client IP resolution (trusted proxy)
# ============================================================================
# Every throttle here is keyed by "who is calling". Behind the production
# ingress (Cloudflare tunnel -> nginx -> api) `request.client.host` is the NGINX
# CONTAINER's IP, identical for every visitor, so keying on it would put the
# whole university in one bucket: one abusive client would rate-limit everyone,
# and the PIN throttle would lock out real admins after five failures by anyone.
#
# Reading a forwarded header instead is only safe if something we control sets
# it — otherwise a caller just sends their own and picks their bucket (or
# poisons someone else's). So trust is OPT-IN and off by default.
#
#   TRUSTED_CLIENT_IP_HEADER  unset (default) -> use the peer address. Correct
#                             when the API is exposed directly, and safe
#                             everywhere else because a spoofed header is ignored.
#                             Production (behind the tunnel): CF-Connecting-IP,
#                             which Cloudflare sets and strips from client input.
#                             A plain reverse proxy: X-Forwarded-For.
#   TRUSTED_PROXY_HOPS        position of the real client from the RIGHT of a
#                             comma-chained header, 1 = rightmost. Single-valued
#                             headers (CF-Connecting-IP, X-Real-IP) use 1.
#                             For this stack's X-Forwarded-For, nginx appends the
#                             cloudflared peer, giving "<client>, <cloudflared>",
#                             so the client sits at position 2.
#
# Counting from the right matters: the left end is attacker-controlled (a client
# can send "X-Forwarded-For: 1.2.3.4" and everything we append lands to its
# right), while each entry on the right was added by a hop we actually run.
_CLIENT_IP_HEADER = os.getenv("TRUSTED_CLIENT_IP_HEADER", "").strip()
_TRUSTED_PROXY_HOPS = max(1, int(os.getenv("TRUSTED_PROXY_HOPS", "1")))


def _parse_ip(value: str) -> Optional[str]:
    """Return `value` if it is a valid IP address, else None.

    Rejecting non-IPs keeps a hostile header from becoming a throttle key:
    unbounded distinct values would both evade the limit and grow the in-memory
    buckets without bound.
    """
    candidate = (value or "").strip()
    if not candidate:
        return None
    # "[2001:db8::1]:443" / "203.0.113.5:1234" -> bare address
    if candidate.startswith("["):
        candidate = candidate[1:].split("]", 1)[0]
    elif candidate.count(":") == 1:
        candidate = candidate.split(":", 1)[0]
    try:
        return str(ipaddress.ip_address(candidate))
    except ValueError:
        return None


def _client_ip(request: Request) -> str:
    """Best available identity for the caller, honouring a trusted proxy header.

    Falls back to the peer address whenever the header is absent, malformed, or
    not configured — never trusts a value we cannot attribute to our own ingress.
    """
    peer = request.client.host if request.client else "unknown"
    if not _CLIENT_IP_HEADER:
        return peer
    raw = request.headers.get(_CLIENT_IP_HEADER, "")
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    if not parts:
        return peer
    index = len(parts) - _TRUSTED_PROXY_HOPS
    if not 0 <= index < len(parts):
        # Chain shorter than configured: someone bypassed a hop, or the config is
        # wrong. Use the leftmost entry (closest to the client) rather than an
        # arbitrary one, then let validation decide.
        index = 0
    return _parse_ip(parts[index]) or peer


# ============================================================================
# Admin Authentication
# ============================================================================
DASHBOARD_PIN = os.getenv("DASHBOARD_PIN", "")

# Simple in-memory rate limiter for PIN verification (brute-force protection)
_pin_attempts: Dict[str, list] = {}       # ip -> [timestamps]
_PIN_MAX_ATTEMPTS = 5
_PIN_WINDOW_SECONDS = 300                  # 5-minute window


def _check_rate_limit(client_ip: str) -> None:
    """Raise 429 if the client has exceeded PIN attempt limits."""
    now = time.time()
    attempts = _pin_attempts.get(client_ip, [])
    attempts = [t for t in attempts if now - t < _PIN_WINDOW_SECONDS]
    _pin_attempts[client_ip] = attempts
    if len(attempts) >= _PIN_MAX_ATTEMPTS:
        raise HTTPException(429, "Too many attempts. Try again later.")


def _record_attempt(client_ip: str) -> None:
    _pin_attempts.setdefault(client_ip, []).append(time.time())


# Rate limiter for /chat. Diwa's /chat is intentionally anonymous, so this is
# the only thing standing between one script and the LLM bill.
#
# TWO tiers, because either one alone fails:
#   per-session  session_id is CHOSEN BY THE CLIENT, so a caller that rotates it
#                every request sees an empty bucket each time — on its own this
#                limit is advisory, it only stops an honest tab from bursting.
#   per-IP       closes that hole, since the address is not client-chosen (given
#                TRUSTED_CLIENT_IP_HEADER is configured). Deliberately much
#                looser: a campus behind one NAT address shares it, so this is a
#                ceiling on abuse, not a per-person quota.
#
# In-memory only — single-worker uvicorn is assumed; multi-worker needs Redis.
#
# The per-IP default is deliberately generous because it is a ceiling on abuse,
# not a capacity limit: the turn gate (CHAT_MAX_CONCURRENT_TURNS) is what bounds
# how much work the server actually accepts. Raising this without that gate in
# place would remove the only backpressure in the stack — the two settings are
# a pair. A whole campus can sit behind one NAT address, so a limit tight enough
# to be a per-person quota just throttles the campus.
_CHAT_MAX_REQUESTS  = int(os.getenv("CHAT_RATE_LIMIT_MAX", "30"))
_CHAT_IP_MAX_REQUESTS = int(os.getenv("CHAT_RATE_LIMIT_IP_MAX", "1200"))
_CHAT_WINDOW_SECONDS = float(os.getenv("CHAT_RATE_LIMIT_WINDOW", "60"))
_chat_hits: Dict[str, list] = {}


def _check_chat_rate_limit(key: str, limit: Optional[int] = None) -> None:
    """Raise 429 if `key` has exceeded its budget for the window."""
    ceiling = _CHAT_MAX_REQUESTS if limit is None else limit
    now = time.time()
    hits = [t for t in _chat_hits.get(key, []) if now - t < _CHAT_WINDOW_SECONDS]
    if len(hits) >= ceiling:
        # Retry-After so the client can back off for a real interval instead of
        # guessing. The window is the honest answer: that is when a slot frees.
        raise HTTPException(
            429,
            "Too many chat requests. Slow down for a moment.",
            headers={"Retry-After": str(int(_CHAT_WINDOW_SECONDS))},
        )
    hits.append(now)
    _chat_hits[key] = hits


def _enforce_chat_limits(request_session_id: Optional[str], http_request: Request) -> None:
    """Apply both chat tiers. IP first: it is the one a client cannot rotate."""
    _check_chat_rate_limit(f"chat:ip:{_client_ip(http_request)}", _CHAT_IP_MAX_REQUESTS)
    if request_session_id:
        _check_chat_rate_limit(f"chat:sid:{request_session_id}")


# ── Admin session cookie ─────────────────────────────────────────────────────
# The PIN used to be kept in sessionStorage and re-attached by JavaScript on
# every admin call, so a single XSS anywhere on the admin origin could lift the
# shared secret itself. Instead /admin/verify exchanges the PIN once for an
# opaque, expiring, httpOnly session token: JS can never read it, it is scoped
# to this browser, and revoking it does not require rotating the PIN.
#
# Server-side store (not a signed token) so /admin/logout can revoke instantly.
# In-memory, consistent with the throttles above — single-worker uvicorn is
# assumed; a multi-worker deploy needs Redis for both.
_ADMIN_COOKIE = "sevi_admin"
_ADMIN_SESSION_TTL = float(os.getenv("ADMIN_SESSION_TTL_SECONDS", "3600"))
_admin_sessions: Dict[str, float] = {}     # token -> expiry (epoch seconds)
# Secure flag for BOTH cookies this app sets (admin session and AIS session).
# Dropped for local http:// development, where the browser would otherwise
# refuse to store them and the dashboard would look like it never unlocks.
# COOKIE_SECURE is the accurate name; ADMIN_COOKIE_SECURE is kept as an alias
# because it shipped first and is referenced in the deploy examples.
_COOKIE_SECURE_RAW = os.getenv("COOKIE_SECURE", os.getenv("ADMIN_COOKIE_SECURE", "1"))
_ADMIN_COOKIE_SECURE = _COOKIE_SECURE_RAW.strip().lower() not in ("0", "false", "no", "off", "")


def _admin_session_new() -> str:
    """Mint a session token, sweeping expired ones so the dict can't grow."""
    now = time.time()
    for token, expiry in list(_admin_sessions.items()):
        if expiry <= now:
            _admin_sessions.pop(token, None)
    token = secrets.token_urlsafe(32)
    _admin_sessions[token] = now + _ADMIN_SESSION_TTL
    return token


def _admin_session_valid(token: str) -> bool:
    if not token:
        return False
    expiry = _admin_sessions.get(token)
    if expiry is None:
        return False
    if expiry <= time.time():
        _admin_sessions.pop(token, None)
        return False
    return True


def _pin_matches(candidate: str) -> bool:
    """Constant-time PIN comparison (never `==`: a short-circuiting compare
    leaks the shared secret's prefix through response timing). Compared as
    bytes so a non-ASCII header can't raise TypeError out of compare_digest."""
    if not DASHBOARD_PIN:
        return False
    return secrets.compare_digest(
        (candidate or "").encode("utf-8"), DASHBOARD_PIN.encode("utf-8")
    )


async def require_admin(request: Request) -> None:
    """Dependency: verify the X-Admin-Pin header matches DASHBOARD_PIN.

    The brute-force throttle and the constant-time compare live HERE, not only
    on /admin/verify — otherwise the ~30 routes carrying this dependency are an
    unthrottled PIN oracle that simply skips the one endpoint that counts
    attempts. Only FAILED attempts consume the budget, so a dashboard polling
    with the correct PIN is never locked out.
    """
    if not DASHBOARD_PIN:
        raise HTTPException(503, "Admin access not configured")
    # 1. Browser path — the httpOnly session cookie minted by /admin/verify.
    # Checked first and NOT throttled: it is an unguessable 256-bit token, and
    # a dashboard polling with a valid session must never consume the PIN
    # budget or it would lock itself out.
    if _admin_session_valid(request.cookies.get(_ADMIN_COOKIE, "")):
        return
    # 2. Script path — the raw PIN. Kept for CI, curl, and the training
    # scripts, which have no cookie jar.
    pin_header = request.headers.get("X-Admin-Pin", "")
    if not pin_header:
        # No credential presented at all. This is NOT a PIN guess, so it must
        # not spend the brute-force budget: a browser whose admin cookie has
        # expired sends exactly this, and counting it would 429 the operator
        # out of the unlock screen after five ordinary page loads.
        raise HTTPException(401, "Unauthorized")
    client_ip = _client_ip(request)
    _check_rate_limit(client_ip)
    if not _pin_matches(pin_header):
        _record_attempt(client_ip)
        raise HTTPException(401, "Unauthorized")


def _internal_identity(http_request: Request) -> Optional[str]:
    """Resolve the authenticated INTERNAL user for this request, or None.

    FAIL-CLOSED fence for the internal capabilities (AIS finance, HR/DTR): those
    short-circuits run ONLY when this returns a user. Anonymous callers get None
    and never reach finance/HR tools — which is why the public, anonymous surface
    stays student-only regardless of the connector enable flags.

    Modes (SEVI_INTERNAL_AUTH_MODE):
      off  (default) — no identity source; internal tools never fire.
      jwt            — PRODUCTION. Verify a short-lived HS256 JWT minted by the
                       Desk (Authorization: Bearer <jwt> or X-Sevi-Token), signed
                       with SEVI_JWT_SECRET, aud="sevi"; the `sub` claim is the user.
      demo           — LOCAL ONLY. Returns SEVI_DEMO_USER for every request so a
                       local stack works without real auth. Never set off-local.

    Trusted-proxy path (any mode, fallback): an auth proxy that already validated
    the Desk session sets `X-Internal-Key` (== INTERNAL_KEY, constant-time
    compared) + `X-Sevi-User`. Sevi never sees the user's password.

    See docs/phase0-auth-fencing.md for the Desk-side JWT minting endpoint.
    """
    # 1. Trusted proxy (any mode).
    key = os.getenv("INTERNAL_KEY", "")
    provided = http_request.headers.get("X-Internal-Key", "")
    if key and secrets.compare_digest(provided, key):
        return http_request.headers.get("X-Sevi-User", "").strip() or "internal-client"
    mode = os.getenv("SEVI_INTERNAL_AUTH_MODE", "off").strip().lower()
    # 2. Signed JWT from the Desk (chosen production mechanism).
    if mode == "jwt":
        return _jwt_identity(http_request)
    # 3. Local demo bypass.
    if mode == "demo":
        return os.getenv("SEVI_DEMO_USER", "demo.user") or None
    return None  # fail closed


def _jwt_identity(http_request: Request) -> Optional[str]:
    """Verify a Desk-minted HS256 JWT and return its `sub` (user), or None.

    Fail-closed: any missing/expired/bad-signature/wrong-audience token -> None.
    Token source: `Authorization: Bearer <jwt>` or the `X-Sevi-Token` header.
    """
    auth = http_request.headers.get("Authorization", "")
    token = auth[7:].strip() if auth.startswith("Bearer ") else ""
    token = token or http_request.headers.get("X-Sevi-Token", "").strip()
    secret = os.getenv("SEVI_JWT_SECRET", "")
    if not (token and secret):
        return None
    try:
        import jwt  # PyJWT
        claims = jwt.decode(token, secret, algorithms=["HS256"], audience="sevi")
    except Exception:  # noqa: BLE001 — invalid/expired/bad-sig -> deny
        return None
    return (claims.get("sub") or "").strip() or None


# ============================================================================
# Request/Response Models
# ============================================================================
# Hard cap on a single chat message. Longer input is truncated before it can
# reach the models / LLM prompt / logs — a client shouldn't be able to inflate
# any of those. Pairs with the per-session rate limiter (_check_chat_rate_limit).
_CHAT_MAX_MESSAGE_CHARS = int(os.getenv("CHAT_MAX_MESSAGE_CHARS", "4000"))

# Device telemetry, validated at the door (see ChatRequest below). The id is
# whatever opaque token the client minted — a UUID today — so the shape is
# bounded rather than parsed. The classes are an allowlist mirroring
# `DeviceClass` in sevi-web app/lib/ids.ts; keep the two in step.
_DEVICE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")
_DEVICE_CLASSES = frozenset({
    "phone/portrait", "phone/landscape",
    "tablet/portrait", "tablet/landscape",
    "desktop/portrait", "desktop/landscape",
    "unknown/unknown",
})


class ChatRequest(BaseModel):
    message: str
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    # How Sevi is actually being reached. `device_id` is a stable opaque id the
    # browser keeps in localStorage, so usage can be counted per DEVICE rather
    # than per session (a student who asks three questions over three days is
    # one device, three sessions); `device_class` is the form factor and
    # orientation of the turn. Both are optional — every client that predates
    # them keeps working, they just do not appear in the device rollup.
    device_id: Optional[str] = None
    device_class: Optional[str] = None
    # Optional escape hatch for external clients (e.g. an admin tool or another
    # service) to call a specific AIS MCP tool without going through the
    # router. When set, `message` is still logged but `intent_hint` wins.
    intent_hint: Optional[str] = None
    intent_args: Optional[Dict[str, Any]] = None
    # Reply-language preference: "en" | "fil" | "auto". Omitted or "auto" keeps
    # the historical behaviour (detect from the question), so every client that
    # predates the selector is unaffected. Asked for in UAT by staff handling
    # walk-in inquiries, where the person asking and the person reading the
    # answer are often not the same.
    language: Optional[str] = None

    @field_validator("language")
    @classmethod
    def _clean_language(cls, v: Optional[str]) -> Optional[str]:
        """Allowlisted and dropped-not-rejected, like device_class above: an
        unrecognised preference should cost the user their language setting for
        that turn, not their answer."""
        if v is None:
            return None
        v = v.strip().lower()
        return v if v in REPLY_LANGUAGES else None

    @field_validator("device_id")
    @classmethod
    def _clean_device_id(cls, v: Optional[str]) -> Optional[str]:
        """Keep the column to opaque client-generated ids.

        Dropped rather than rejected: a malformed id is a broken metric, not a
        reason to fail a student's question. The bound also stops the field
        being used as a smuggling channel for free text into the logs.
        """
        if v is None:
            return None
        return v if _DEVICE_ID_RE.match(v) else None

    @field_validator("device_class")
    @classmethod
    def _clean_device_class(cls, v: Optional[str]) -> Optional[str]:
        """Allowlisted, so the rollup below can group on it without first
        having to defend against whatever a caller felt like sending."""
        if v is None:
            return None
        return v if v in _DEVICE_CLASSES else None

    @field_validator("message")
    @classmethod
    def _sanitize_message(cls, v: str) -> str:
        """Defense-in-depth on the one free-text field: drop control characters
        (keep tab/newline), trim, and hard-cap the length. The empty-message 400
        is still enforced in the endpoint; this only bounds oversized/'binary'
        input before it reaches the pipeline."""
        v = "".join(ch for ch in v if ch in "\t\n" or ord(ch) >= 32).strip()
        return v[:_CHAT_MAX_MESSAGE_CHARS]

# Campus map (48 official locations) — see api/campus_places.py
# All functions are now DB-primary with hardcoded fallback.
from api.campus_places import (
    MapData,
    PlaceMeta,
    Directory,
    resolve_map_data as _resolve_map_data,
    resolve_directory as _resolve_directory,
    build_place_meta as _build_place_meta,
    campus_map_payload as _campus_map_payload,
    has_place as _has_place,
    get_all_places as _get_all_places,
    save_coord_overrides as _save_coord_overrides,
    list_coord_overrides as _list_coord_overrides,
    reset_coord_overrides as _reset_coord_overrides,
    save_waypoint_overrides as _save_waypoint_overrides,
    list_waypoint_overrides as _list_waypoint_overrides,
    reset_waypoint_overrides as _reset_waypoint_overrides,
    delete_waypoint_override as _delete_waypoint_override,
    list_custom_markers as _list_custom_markers,
    upsert_custom_marker as _upsert_custom_marker,
    delete_custom_marker as _delete_custom_marker,
)

from api.db import ensure_schema as _ensure_db_schema

# Ensure all DB tables exist at startup (idempotent)
try:
    _ensure_db_schema()
except Exception:
    pass


class CoordEntry(BaseModel):
    x: int
    y: int


class WaypointEntry(BaseModel):
    """Waypoint coordinate plus optional adjacency list. The frontend uses
    `neighbors` for custom waypoints so they can be wired into the routing
    graph without code changes."""
    x: int
    y: int
    neighbors: Optional[List[str]] = None


class CoordsUpdate(BaseModel):
    """Body for PUT /map/coords. Keys are place_ids."""
    coords: Dict[str, CoordEntry]


class WaypointsUpdate(BaseModel):
    """Body for PUT /map/waypoints. Values may carry an adjacency list."""
    coords: Dict[str, WaypointEntry]


class CustomMarkerCreate(BaseModel):
    id: str
    name: str
    x: int
    y: int
    abbr: Optional[str] = None
    num: Optional[int] = None


def _is_header_line(line: str) -> bool:
    s = line.strip()
    if len(s) < 25:
        return True
    if s.endswith(":") and len(s) < 60:
        return True
    letters = [c for c in s if c.isalpha()]
    return bool(letters) and all(c.isupper() for c in letters)


def _trim_to_sentence(head: str, max_chars: int) -> str:
    if len(head) <= max_chars:
        return head
    for terminator in (". ", "? ", "! "):
        idx = head.find(terminator)
        if 30 < idx < max_chars:
            return head[: idx + 1].strip()
    return head[:max_chars].rstrip() + "…"


# Office phone numbers are withheld from chat output (data-privacy: numbers
# rot and the official directory stays authoritative). Crisis-line responses
# (mental_health_immediate) are exempt — stripping NCMH/Hopeline numbers from
# them would be harmful. Short emergency codes (911, 1553) never match these
# patterns. SafetyGate refusals short-circuit before redaction ever runs.
_PHONE_REDACT_EXEMPT_INTENTS = {"mental_health_immediate"}
_PHONE_RE = re.compile(
    r"(?:\+63[\s.-]?\d{2,3}[\s.-]?\d{3}[\s.-]?\d{4}"  # +63 998 937 2020
    r"|\(0\d{1,2}\)\s?\d{3,4}[\s.-]?\d{4}"            # (046) 862-0850 / (02) 8804-4673
    r"|\b09\d{2}[\s.-]?\d{3}[\s.-]?\d{4}\b)"          # 0917 558-4673 / 09171234567
)
_PHONE_PLACEHOLDER = "[see the official directory at cvsu.edu.ph]"
# Collapses "[see …] / [see …]" chains left by multi-number listings.
_PHONE_COLLAPSE_RE = re.compile(
    re.escape(_PHONE_PLACEHOLDER)
    + r"(?:\s*[/,;]?\s*(?:or\s+)?"
    + re.escape(_PHONE_PLACEHOLDER)
    + r")+"
)


def _redact_office_phones(text: str, intent: Optional[str] = None) -> str:
    if not text or intent in _PHONE_REDACT_EXEMPT_INTENTS:
        return text
    redacted, hits = _PHONE_RE.subn(_PHONE_PLACEHOLDER, text)
    if hits < 2:  # 0 or 1 replacement — no placeholder chain to collapse
        return redacted
    return _PHONE_COLLAPSE_RE.sub(_PHONE_PLACEHOLDER, redacted)


# Display formatting — many corpus responses (esp. the Tagalog variants) are a
# single dense paragraph. The web renderer already handles headings, bullets
# and paragraphs, so give it structure: sentence-per-block, and colon
# enumerations ("events: A, B, at C") become bullet lists. Splitting is
# parenthesis-aware so "(Enero 28–29, 2026, kasama …)" stays intact.
_ABBREV_TAIL_RE = re.compile(
    r"\b(?:hal|e\.g|i\.e|etc|No|Blg|Mr|Mrs|Ms|Dr|Engr|Atty|Sta|Sto|s|loc)\.$", re.IGNORECASE
)


# A name initial or short title before the period ("Dr. Ma. Agnes P. Nuestro"):
# a 1–2 char capitalized token is never a real sentence end.
_INITIAL_TAIL_RE = re.compile(r"(?:^|\s)[A-Z][a-z]?\.$")


def _split_outside_parens(text: str, boundary: str) -> List[str]:
    """Split on `boundary` ('. ' sentence ends or ', ' list commas) at paren
    depth 0. Sentence mode skips known abbreviations ("hal.", "No.") and name
    initials ("Ma.", "P.")."""
    parts, depth, start, i = [], 0, 0, 0
    while i < len(text) - 1:
        ch = text[i]
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth = max(0, depth - 1)
        elif depth == 0 and text[i : i + 2] == boundary:
            head = text[start : i + (1 if boundary == ". " else 0)]
            tail = head.rstrip()
            if boundary != ". " or not (
                _ABBREV_TAIL_RE.search(tail) or _INITIAL_TAIL_RE.search(tail)
            ):
                parts.append(head.strip())
                start = i + 2
        i += 1
    parts.append(text[start:].strip())
    return [p for p in parts if p]


def _bulletize(sentence: str) -> Optional[str]:
    """Turn 'intro: A, B, C, at D.' into an intro line + bullet list."""
    m = re.search(r": (?!\d)", sentence)
    if not m:
        return None
    intro, rest = sentence[: m.start()], sentence[m.end() :]
    items = _split_outside_parens(rest, ", ")
    # Only bulletize real enumerations: 3+ items, at least half of them
    # substantial — keeps "Indang, Cavite"-style addresses as prose.
    if len(items) < 3 or sum(len(i) >= 12 for i in items) * 2 < len(items):
        return None
    # "at Graduation." / "and Graduation" — drop the conjunction on the last item.
    items[-1] = re.sub(r"^(?:at|and)\s+", "", items[-1], flags=re.IGNORECASE)
    return intro + ":\n" + "\n".join(f"- {item.rstrip('.')}" for item in items)


# A lead-in that introduces an enumeration without a colon: "examples
# include A; B; C". Used to keep the lead-in as a heading over the bullets.
_LEADIN_RE = re.compile(
    r"\b(?:includes?|including|such as|namely|are|offers?)\s+", re.IGNORECASE
)


def _bulletize_semicolons(sentence: str) -> Optional[str]:
    """Turn 'intro include A (x); B (y); C (z).' into a heading + bullet list.

    _bulletize only fires on a colon-introduced, comma-separated list. Curated
    answers frequently enumerate with semicolons and no colon instead — the
    courses_offered reply is one 1,660-character sentence listing 14 colleges
    that way, and rendered as a single wall of prose in the UI.
    """
    parts = _split_outside_parens(sentence, "; ")
    # Same shape test as _bulletize: a real enumeration, not an aside.
    if len(parts) < 3 or sum(len(p) >= 12 for p in parts) * 2 < len(parts):
        return None
    intro = None
    match = _LEADIN_RE.search(parts[0])
    if match:
        intro, parts[0] = parts[0][: match.end()].rstrip(), parts[0][match.end():]
    parts[-1] = re.sub(r"^(?:and|at)\s+", "", parts[-1], flags=re.IGNORECASE)
    items = [p.strip().rstrip(".") for p in parts if p.strip()]
    if len(items) < 3:
        return None
    body = "\n".join(f"- {item}" for item in items)
    return f"{intro}:\n{body}" if intro else body


# A paragraph that already carries list markers ("1. …", "- …") is authored
# structure, not a wall of prose. Reflowing it splits on the "1. " marker itself
# and leaves the number stranded on its own line ("1.\n\nFILE THE ONLINE …"),
# which is exactly the shape this formatter exists to prevent.
_STRUCTURED_LINE_RE = re.compile(r"^\s*(?:\d{1,3}[.)]|[-*•])\s+\S", re.MULTILINE)


def _format_paragraph(paragraph: str) -> str:
    if len(paragraph) < 240 or _STRUCTURED_LINE_RE.search(paragraph):
        return paragraph
    # A provenance footnote is a citation, not prose to reflow. It is long
    # (document, edition, page, service, office, link) and comma-separated, so
    # the enumeration heuristics below shred it into "- CvSU Citizens' Charter
    # / - FY 2026 edition / - p" — turning the one line that exists to be
    # checkable into nonsense. Same prefixes response_blocks calls a NoteBlock.
    if NOTE_PREFIX_RE.match(paragraph):
        return paragraph
    sentences = _split_outside_parens(paragraph, ". ")
    return "\n\n".join(
        _bulletize(s) or _bulletize_semicolons(s) or s for s in sentences
    )


def _format_display_text(text: str) -> str:
    if not text:
        return text
    # Format per paragraph rather than bailing on the whole reply at the first
    # newline: a mostly-structured answer can still hide one dense enumeration
    # paragraph, which is exactly the case the old whole-text guard skipped.
    return "\n\n".join(
        _format_paragraph(p) if p.strip() else p
        for p in text.split("\n\n")
    )


def _extract_summary(text: str, max_chars: int = 240) -> str:
    """Pull the first meaningful paragraph or sentence from a response.

    Skips header-like lines ("CvSU REGISTRAR SERVICES:", all-caps, ends with
    a colon, or too short) so the UI summary never looks like just a heading.
    """
    if not text:
        return ""
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    for para in paragraphs:
        if _is_header_line(para.split("\n", 1)[0]):
            continue
        return _trim_to_sentence(para.replace("\n", " ").strip(), max_chars)
    if paragraphs:
        return _trim_to_sentence(paragraphs[0].replace("\n", " "), max_chars)
    return text[:max_chars].strip()


# ─────────────────────────────────────────────────────────────────────────────
# Chat response envelope (v2)
#
# A `/chat` reply is the text plus a typed list of cards (map, directory, DV
# detail, table) plus provenance (which tier answered) plus a hint to the UI
# about how to lay it out. Replaces the v1 flat shape with `map_data /
# directory / dv_card / table` as separate optional fields.
# ─────────────────────────────────────────────────────────────────────────────


class ResponseSource(str, Enum):
    """Which tier of the cascade produced the reply."""
    NAIVE_BAYES     = "naive_bayes"
    NEURAL_NETWORK  = "neural_network"
    LLM_LOCAL       = "llm_local"
    LLM_CLAUDE      = "llm_claude"
    LLM_UNAVAILABLE = "llm_unavailable"    # a provider was configured but down/errored this turn
    AIS_MCP         = "ais_mcp"
    CONNECTORS_MCP  = "connectors_mcp"
    WORKFLOW        = "workflow"            # Tier 5.5 — stateful agentic workflow
    CHARTER_RAG     = "charter_rag"
    SITE_RAG        = "site_rag"
    INTENT_RETRIEVAL = "intent_retrieval"
    CAMPUS_DIRECTORY = "campus_directory"  # charter contact-table answers
    PLACE_RESOLVER  = "place_resolver"     # deterministic campus wayfinding
    CONVERSATION_RECAP = "conversation_recap"  # session recap from chat history
    SMALLTALK       = "smalltalk"          # curated benign small talk (jokes)
    COLLEGE_PROGRAMS = "college_programs" # complete per-college program list
    FALLBACK        = "fallback"
    REFUSAL         = "refusal"


class RefusalReason(str, Enum):
    """Set when source == REFUSAL — why the reply is a refusal."""
    NONSENSE      = "nonsense"
    OUT_OF_SCOPE  = "out_of_scope"
    PROHIBITED    = "prohibited"
    ABUSIVE       = "abusive"   # profanity/insult directed at a person or the bot
    SAFETY        = "safety"    # self-harm referral or threat boundary


class DisplayHint(str, Enum):
    """How the frontend should lay out the response."""
    DEFAULT     = "default"      # text bubble first, cards under
    MAP_FIRST   = "map_first"    # show the map above the text
    CARD_FIRST  = "card_first"   # show the structured card (DV / table) first
    TEXT_ONLY   = "text_only"    # no cards expected; tighten spacing


class DirectoryCard(BaseModel):
    """Office / contact card."""
    kind: Literal["directory"] = "directory"
    office: str
    location: Optional[str] = None
    place_id: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    hours: Optional[str] = None


class MapCard(BaseModel):
    """Campus map preview, expandable to fullscreen on the frontend."""
    kind: Literal["map"] = "map"
    place_id: str
    label: str
    default_open: bool = False


class DvCard(BaseModel):
    """Structured DV detail surfaced when the AIS MCP bridge handles a get_dv."""
    kind: Literal["dv"] = "dv"
    name: str
    control_number: Optional[str] = None
    payee: str = ""
    amount: float = 0.0
    workflow_status: str = ""
    posting_date: Optional[str] = None
    fund_cluster: Optional[str] = None
    ors_burs_reference: Optional[str] = None
    dv_type: Optional[str] = None
    desk_url: str
    # Phase 2A Wave 2 — frontend round-trips this as expected_modified on
    # /ais/write so the server-side optimistic-lock check can catch stale
    # writes when another session changed the DV between read and confirm.
    modified: Optional[str] = None


class TableColumn(BaseModel):
    key: str
    label: str
    align: Optional[Literal["left", "right", "center"]] = None


class TableCard(BaseModel):
    """Multi-row table for list/find/group results.
    Rows are keyed by column.key (matches the existing frontend TableCard
    component which accesses `row[c.key]`)."""
    kind: Literal["table"] = "table"
    title: str = ""
    columns: List[TableColumn] = Field(default_factory=list)
    rows: List[Dict[str, Any]] = Field(default_factory=list)
    footer: Optional[str] = None
    total_rows: Optional[int] = None


ChatCard = Annotated[
    Union[DirectoryCard, MapCard, DvCard, TableCard],
    Field(discriminator="kind"),
]


class UacsContext(BaseModel):
    kind: Literal["object", "funding_source", "responsibility_center"]
    query: Optional[str] = None


class ChatContext(BaseModel):
    """Conversation memory the frontend can surface as a 'talking about …' chip."""
    dv: Optional[str] = None
    uacs: Optional[UacsContext] = None
    report: Optional[str] = None


class SourceCitation(BaseModel):
    """Provenance for a curated intent reply — the official document (Citizens'
    Charter page or official-site URL) the intent's answer is grounded in.
    Populated from data/intent_sources.json for intent-tier replies; the RAG
    and LLM tiers already carry citations inside their prose."""
    kind: Literal["charter", "site"]
    locator: str                 # charter PDF page number, or site URL
    label: Optional[str] = None  # doc title for site refs
    citation: str                # rendered one-line citation
    # Where the reader can go and check it themselves: a "#page=N" deep link
    # into the charter PDF, or the site URL. None when no PDF is published
    # (CHARTER_PDF_URL unset) — a renderer should then show text only.
    url: Optional[str] = None
    # Charter refs only — the service documented on that page and the office
    # that owns it, so a client can render a chip without parsing `citation`.
    section: Optional[str] = None
    office: Optional[str] = None


class ChatResponse(BaseModel):
    model_config = ConfigDict(protected_namespaces=())

    # Identity — message_id is None when logging is best-effort and didn't yield
    # an id (log_chat swallows errors and returns None); a chat reply must never
    # 500 just because the audit write failed.
    message_id: Optional[int] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None

    # Content — `text` is the raw body (kept for older clients and for the audit
    # log); `blocks` is the same content parsed into typed structure, and is what
    # a renderer should prefer. See api/response_blocks.py.
    text: str
    blocks: List[ContentBlock] = Field(default_factory=list)
    summary: Optional[str] = None

    # Classification + provenance
    intent: str
    confidence: float = 0.0
    source: ResponseSource
    refusal_reason: Optional[RefusalReason] = None

    # Structured attachments — empty list if none
    cards: List[ChatCard] = Field(default_factory=list)
    context: Optional[ChatContext] = None
    suggestions: List[str] = Field(default_factory=list)
    # Official source(s) backing a curated intent reply — empty for RAG/LLM
    # tiers (which cite inline) and for refusals/fallback.
    sources: List[SourceCitation] = Field(default_factory=list)

    # Layout hint for the renderer
    display_hint: DisplayHint = DisplayHint.DEFAULT

    @model_validator(mode="after")
    def _derive_blocks(self) -> "ChatResponse":
        """Every reply carries `blocks`, whichever tier built it — derived from
        `text` unless a caller passed blocks explicitly. Keeping this on the
        model means a new short-circuit path can't ship a block-less reply."""
        if not self.blocks and self.text:
            self.blocks = _parse_blocks(self.text)
        return self

class IntentInfo(BaseModel):
    tag: str
    pattern_count: int
    response_count: int
    sample_patterns: List[str]

class ModelInfo(BaseModel):
    """Sanitized model info — no internal details exposed."""
    model_config = ConfigDict(protected_namespaces=())
    total_intents: int

class FeedbackRequest(BaseModel):
    message_id: Optional[int] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    intent: Optional[str] = None
    rating: Optional[int] = None          # 1–5
    helpful: Optional[bool] = None
    reason: Optional[str] = None          # structured taxonomy code (see /feedback/reasons)
    comment: Optional[str] = None         # free-text qualitative detail
    suggested_intent: Optional[str] = None
    user_message: Optional[str] = None    # store query directly when message_id unavailable


# Structured reason taxonomy. Keep in sync with the frontends
# (web/app/components/ChatMessage.tsx and web/web_interface.html).
FEEDBACK_REASONS = {
    "positive": [
        {"code": "accurate",   "label": "Got my answer"},
        {"code": "clear",      "label": "Easy to understand"},
        {"code": "helpful",    "label": "Pointed me the right way"},
        {"code": "other",      "label": "Something else"},
    ],
    "negative": [
        {"code": "wrong_info",   "label": "Contains incorrect information"},
        {"code": "wrong_topic",  "label": "Answered something else"},
        {"code": "incomplete",   "label": "Missing key details"},
        {"code": "outdated",     "label": "Looks out of date"},
        {"code": "confusing",    "label": "Hard to understand"},
        {"code": "other",        "label": "Something else"},
    ],
}
_VALID_REASON_CODES = {r["code"] for group in FEEDBACK_REASONS.values() for r in group}

class FeedbackAnalyzeRequest(BaseModel):
    session_id: Optional[str] = None
    user_id: Optional[str] = None
    intent: Optional[str] = None
    min_rating: Optional[int] = None
    max_rating: Optional[int] = None
    helpful: Optional[bool] = None
    limit: int = 5000
    apply: bool = False                   # write changes to cavsu_intents.json

# Note: HybridChatbot is now imported from hybrid_chatbot.py
# It combines Naive Bayes (fast) + Neural Network (accurate)

# ============================================================================
# Initialize Chatbot and Logger
# ============================================================================
MODEL_DIR = "models"

# Initialize Hybrid Chatbot (Naive Bayes + Neural Network)
chatbot = HybridChatbot(
    model_dir=MODEL_DIR,
    responses_path=os.path.join(MODEL_DIR, "responses_map.json")
)

# Initialize chat logger
chat_logger = ChatLogger(log_dir="logs", db_path="logs/chat_history.db")

# P1-5: persist cross-tier arbitration disagreements — the weekly review queue
# served at GET /admin/tier_disagreements. Wired here (and re-wired on
# /model/reload) because the chatbot is constructed before the logger exists.
chatbot.disagreement_logger = chat_logger.log_tier_disagreement

# Chat-log writes get their own single-thread executor.
#
# They were being made synchronously from async handlers, so every turn blocked
# the event loop on a disk write — which also stalls /health, and a healthcheck
# that fails under load gets the container restarted by compose exactly when it
# is busiest. One thread, not several: ChatLogger already serializes writers
# behind its own lock, so more threads would only add contention. Separate from
# the default pool so a burst of log writes can never starve chat turns of
# worker threads.
_log_pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="sevi-log")


async def _log_chat(**kwargs):
    """Write one chat-log row off the event loop, returning its message id.

    The id goes into the reply, so this is awaited rather than fire-and-forget;
    the point is to stop blocking the loop, not to drop the write.
    """
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        _log_pool, functools.partial(chat_logger.log_chat, **kwargs)
    )

# ============================================================================
# API Endpoints
# ============================================================================

@app.get("/", tags=["Health"])
async def root():
    """Root endpoint - API status."""
    return {
        "service": "DIWA API",
        "status": "active",
    }

@app.get("/health", tags=["Health"])
async def health_check():
    """Liveness probe — deliberately minimal (P0-3, HANDOFF-QUALITY 2026-08-03).

    The compose healthcheck (`curl -fsS`) and the web frontend's online badge
    only need `status`. Everything the old payload carried — build hash, LLM
    provider + internal base URL, `llm_error`, turn-gate internals — described
    internal infrastructure to unauthenticated callers. That full payload now
    lives on the admin-gated GET /admin/status."""
    return {"status": "healthy"}

# ─────────────────────────────────────────────────────────────────────────────
# Response-shape helpers (v2 envelope)
# ─────────────────────────────────────────────────────────────────────────────

# Intents whose answer is about *where* something is — the map should render
# above the text in those cases. Kept in sync with the frontend's
# MAP_FIRST_INTENT_RE in ChatMessage.tsx.
_MAP_FIRST_INTENT_RE = re.compile(r"direction|location|where|map|find_place|navigate|route", re.I)

# Maps the `model_used` string the chatbot returns into the public-facing
# (source, refusal_reason) pair on ChatResponse.
def _classify_source(model_used: Optional[str]) -> tuple[ResponseSource, Optional[RefusalReason]]:
    if not model_used:
        return ResponseSource.FALLBACK, None
    m = model_used
    if m.startswith("Naive Bayes"):
        return ResponseSource.NAIVE_BAYES, None
    if m == "Neural Network":
        return ResponseSource.NEURAL_NETWORK, None
    if m == "ais_mcp":
        return ResponseSource.AIS_MCP, None
    if m == "connectors_mcp":
        return ResponseSource.CONNECTORS_MCP, None
    if m == "hr_mcp":
        # HR/DTR is live-data too; classify as a connectors-style source so the
        # frontend renders it as a real answer, not the nlu-fallback UI.
        return ResponseSource.CONNECTORS_MCP, None
    if m.startswith("Charter RAG"):
        return ResponseSource.CHARTER_RAG, None
    if m.startswith("Site RAG"):
        return ResponseSource.SITE_RAG, None
    if m.startswith("Intent Retrieval"):
        return ResponseSource.INTENT_RETRIEVAL, None
    if m == "Place Resolver":
        return ResponseSource.PLACE_RESOLVER, None
    if m == "Conversation Recap":
        return ResponseSource.CONVERSATION_RECAP, None
    if m == "Small Talk":
        return ResponseSource.SMALLTALK, None
    if m == "College Programs":
        return ResponseSource.COLLEGE_PROGRAMS, None
    if m.startswith("NonsenseGate"):
        return ResponseSource.REFUSAL, RefusalReason.NONSENSE
    if m.startswith("ScopeGate") or "(out-of-scope)" in m:
        return ResponseSource.REFUSAL, RefusalReason.OUT_OF_SCOPE
    if m.startswith("Claude"):
        return ResponseSource.LLM_CLAUDE, None
    if m.startswith("Local LLM") or m.startswith("Ollama"):
        return ResponseSource.LLM_LOCAL, None
    if m == "LLM Unavailable":
        # A provider was configured but unreachable/errored — render as a normal
        # "try again" message, not the nlu-fallback "rephrase" UI (which keys off
        # source == "fallback" on the frontend).
        return ResponseSource.LLM_UNAVAILABLE, None
    return ResponseSource.FALLBACK, None


# Tiers that serve a *curated* response with no inline citation — these get an
# appended "Source:" block + structured `sources` from the per-intent bindings.
# The RAG/LLM tiers already cite their passages in-prose, so they are excluded.
_INTENT_TIER_SOURCES = frozenset({
    ResponseSource.NAIVE_BAYES,
    ResponseSource.NEURAL_NETWORK,
    ResponseSource.INTENT_RETRIEVAL,
})


def _intent_grounding_for(
    intent: Optional[str], source: ResponseSource
) -> tuple[str, List[SourceCitation]]:
    """(citation_block_text, sources) for a curated intent reply, else ("", []).

    Only intent-tier replies with a verified binding are cited; everything else
    (RAG, LLM, refusal, fallback, unbound intents) returns no citation."""
    if source not in _INTENT_TIER_SOURCES:
        return "", []
    index = _intent_grounding.get_index()
    if index is None:
        return "", []
    refs = index.refs_for(intent)
    if not refs:
        return "", []
    cards = []
    for r in refs:
        page = _charter_pages.describe(int(r.locator)) if r.kind == "charter" and r.locator.isdigit() else None
        cards.append(SourceCitation(
            kind=r.kind, locator=r.locator,
            label=r.label or None, citation=r.citation(), url=r.url,
            section=page.title if page else None,
            office=page.office if page else None,
        ))
    return _intent_grounding.citation_block(refs), cards


def _context_from_ais(ctx: Optional[Dict[str, Any]]) -> Optional[ChatContext]:
    """Lift the AIS bridge's free-form context dict into a typed ChatContext."""
    if not ctx:
        return None
    uacs: Optional[UacsContext] = None
    if ctx.get("uacs_kind"):
        try:
            uacs = UacsContext(kind=ctx["uacs_kind"], query=ctx.get("uacs_query"))
        except Exception:
            uacs = None
    return ChatContext(dv=ctx.get("dv") or None, uacs=uacs, report=ctx.get("report") or None)


def _table_from_dict(t: Optional[Dict[str, Any]]) -> Optional[TableCard]:
    """Convert the AIS bridge's raw table dict into a typed TableCard."""
    if not t:
        return None
    try:
        cols = [
            TableColumn(key=c.get("key", ""), label=c.get("label", c.get("key", "")), align=c.get("align"))
            for c in t.get("columns", [])
        ]
        return TableCard(
            title=t.get("title", ""),
            columns=cols,
            rows=t.get("rows", []) or [],
            footer=t.get("footer"),
            total_rows=t.get("total_rows"),
        )
    except Exception as exc:
        _logger.warning("Could not coerce AIS table into TableCard: %s", exc)
        return None


def _build_attachments(
    *,
    message: str,
    intent: str,
    ais_dv_card: Optional[DvCard],
    ais_table: Optional[Dict[str, Any]],
    ais_context_set: Optional[Dict[str, Any]],
    campus: Optional[str] = None,
    place_id: Optional[str] = None,
) -> tuple[List[ChatCard], Optional[ChatContext], DisplayHint]:
    """Resolve every typed card the reply should carry, plus the layout hint.
    `campus` is the session's resolved campus (campus_context) — when it is a
    satellite, the Indang map card is suppressed so the reply never pairs
    General Trias text with a Don Severino map. `place_id` is the Place
    Resolver's resolution for this turn (nlu_data) — when set, the map card
    reuses it so the text and the pin can never disagree."""
    cards: List[ChatCard] = []

    # AIS card / table take top billing when present.
    if ais_dv_card is not None:
        cards.append(ais_dv_card)
    table_card = _table_from_dict(ais_table)
    if table_card is not None:
        cards.append(table_card)

    # Directory card (office contact). Resolved from the intent.
    dir_data = _resolve_directory(intent)
    if dir_data is not None:
        cards.append(
            DirectoryCard(
                office=dir_data.office,
                location=dir_data.location,
                place_id=dir_data.place_id,
                email=dir_data.email,
                phone=dir_data.phone,
                hours=dir_data.hours,
            )
        )

    # Map preview / accordion. The only map we have depicts the Indang main
    # campus — never attach it while the conversation is about a satellite.
    if _campus_directory.is_satellite(campus):
        map_data = None
    elif place_id and _has_place(place_id):
        map_data = MapData(place_id=place_id, label=_build_place_meta(place_id).label)
    else:
        map_data = _resolve_map_data(message, intent)
    if map_data is not None:
        is_map_first = bool(intent and _MAP_FIRST_INTENT_RE.search(intent))
        cards.append(
            MapCard(place_id=map_data.place_id, label=map_data.label, default_open=is_map_first)
        )

    # Display hint
    if ais_dv_card is not None or table_card is not None:
        hint = DisplayHint.CARD_FIRST
    elif map_data is not None and _MAP_FIRST_INTENT_RE.search(intent or ""):
        hint = DisplayHint.MAP_FIRST
    elif not cards:
        hint = DisplayHint.TEXT_ONLY
    else:
        hint = DisplayHint.DEFAULT

    return cards, _context_from_ais(ais_context_set), hint


async def _short_circuit_response(
    request: "ChatRequest",
    log_message: str,
    start_time: float,
    *,
    text: str,
    intent: str,
    source: ResponseSource,
    model_used: str,
    refusal_reason: Optional[RefusalReason] = None,
    suggestions: Optional[List[str]] = None,
    cards: Optional[List[ChatCard]] = None,
) -> ChatResponse:
    """Build + log a terminal reply for a gate that answers before the NLU
    cascade (safety refusal, campus clarify, campus directory). `log_message`
    is the user's ORIGINAL text — request.message may have been mutated by a
    gate."""
    message_id = await _log_chat(
        user_id=request.user_id or "anonymous",
        user_message=log_message,
        bot_response=text,
        intent=intent,
        confidence=1.0,
        model_used=model_used,
        session_id=request.session_id,
        response_time_ms=(time.time() - start_time) * 1000,
        device_id=request.device_id,
        device_class=request.device_class,
    )
    return ChatResponse(
        message_id=message_id,
        user_id=request.user_id,
        session_id=request.session_id,
        text=text,
        summary=None,
        intent=intent,
        confidence=1.0,
        source=source,
        refusal_reason=refusal_reason,
        cards=cards or [],
        context=None,
        suggestions=suggestions or [],
        display_hint=DisplayHint.DEFAULT if cards else DisplayHint.TEXT_ONLY,
    )


def _safety_block(category: str, model_used: str) -> dict:
    """ChatResponse fields for a safety refusal (self_harm / threat / abuse)."""
    return {
        "text": _safety.RESPONSES[category],
        "intent": f"safety_{category}",
        "source": ResponseSource.REFUSAL,
        "model_used": model_used,
        "refusal_reason": (
            RefusalReason.ABUSIVE if category == "abuse" else RefusalReason.SAFETY
        ),
        "suggestions": _safety.SUGGESTIONS[category],
    }


def _cooldown_block(seconds: int) -> dict:
    """ChatResponse fields for a repeat-abuse cooldown — escalated copy that
    replaces the standard boundary once a session keeps tripping the gate."""
    return {
        "text": _safety.cooldown_response(seconds),
        "intent": "safety_cooldown",
        "source": ResponseSource.REFUSAL,
        "model_used": f"SafetyGate (cooldown {seconds}s)",
        "refusal_reason": RefusalReason.ABUSIVE,
        "suggestions": _safety.SUGGESTIONS["abuse"],
    }


async def _safety_screen(message: str, session_id: Optional[str]):
    """Front-door SafetyGate, shared by /chat and /batch so neither is an
    unscreened path. Returns (block, effective_message):
      • block is a dict of ChatResponse fields when the message must be
        refused (self-harm / threat / abuse / cooldown), else None;
      • effective_message is the message to process downstream (sanitized when
        profanity was mere seasoning, otherwise unchanged).

    Progressive friction: repeated DIRECTED abuse from one session escalates to
    a short cooldown reply (see api/safety.py). Two invariants hold — self-harm
    is checked first and always reaches the referral (never cooled), and a clean
    question is never held (the cooldown only changes the reply to more abuse)."""
    result = _safety.classify(message)

    # Self-harm wins over everything and is never rate-limited: a person in
    # crisis must always reach the referral, whatever they sent before.
    if result.category == "self_harm":
        _safety.record("self_harm", message, session_id, result.max_severity)
        return _safety_block("self_harm", "SafetyGate (self_harm)"), message

    if result.category in ("threat", "abuse"):
        _safety.record(result.category, message, session_id, result.max_severity)
        _safety.note_abuse(session_id)  # threats also count toward escalation
        # Only directed abuse gets softened into a cooldown; a threat always
        # gets the firm threat boundary, never a "take a break" reply.
        if result.category == "abuse":
            remaining = _safety.cooldown_remaining(session_id)
            if remaining:
                return _cooldown_block(remaining), message
        return _safety_block(result.category, f"SafetyGate ({result.category})"), message

    if result.category == "intensifier":
        _safety.record("intensifier", message, session_id, result.max_severity)
        return None, result.sanitized

    # Lexicon said safe — the opt-in LLM second opinion catches paraphrased
    # self-harm/threats the wordlists can't (no-op unless enabled + prefilter).
    llm_cat = await _safety.llm_second_opinion(message)
    if llm_cat:
        _safety.record(llm_cat, message, session_id)
        return _safety_block(llm_cat, f"SafetyGate (llm:{llm_cat})"), message
    return None, message


# How many chat turns may run at once, how many may queue behind them, and how
# long a queued turn waits before we give up on it. A turn is mostly network
# wait (the Claude call), so the ceiling is about bounding memory and provider
# concurrency, not CPU. Local providers are the exception: llama.cpp-class
# backends spike memory per inference, so keep this at 1 for ollama/localai.
_TURN_LIMIT = max(1, int(os.getenv("CHAT_MAX_CONCURRENT_TURNS", "4")))
_TURN_QUEUE_MAX = max(0, int(os.getenv("CHAT_QUEUE_MAX", "16")))
_TURN_QUEUE_TIMEOUT = float(os.getenv("CHAT_QUEUE_TIMEOUT", "25"))


class ChatTurnRunner:
    """Admission control for chat turns.

    Replaces the single global lock that allowed exactly one turn server-wide —
    which meant one student's 12s LLM question stalled every other student's
    50ms FAQ answer. Two things it provides:

      run()        bounded concurrency: N turns in flight, a bounded queue
                   behind them, and a fast 503 past that rather than a wait
                   that outlives the client's patience (and nginx's timeout).
      exclusive()  a drain — no turn in flight — for the admin paths that swap
                   the chatbot or its LLM out from under a running turn.

    Deliberately an object rather than loose module state: changing the
    concurrency model (or later moving admission control into Redis for a
    multi-worker deploy) becomes a swap here instead of edits at five call
    sites. chatbot.chat is passed in per call, never captured, so /model/reload
    rebinding the global still takes effect on the next turn.
    """

    def __init__(self, limit: int, queue_max: int, queue_timeout: float):
        self.limit = limit
        self.queue_max = queue_max
        self.queue_timeout = queue_timeout
        self._sem = asyncio.Semaphore(limit)
        # Serializes drains against each other. Without it two concurrent
        # drains can each hold a subset of the permits and wait forever for the
        # rest — a deadlock that no timeout would clear.
        self._drain_lock = asyncio.Lock()
        self.waiting = 0
        self.in_flight = 0

    def _busy(self) -> HTTPException:
        return HTTPException(
            status_code=503,
            detail="Sevi is helping a lot of students right now. Please try again in a moment.",
            headers={"Retry-After": "5"},
        )

    @asynccontextmanager
    async def slot(self):
        """Hold one turn permit, or raise 503 rather than queue unboundedly."""
        if self.waiting >= self.queue_max:
            raise self._busy()
        self.waiting += 1
        try:
            await asyncio.wait_for(self._sem.acquire(), self.queue_timeout)
        except (asyncio.TimeoutError, TimeoutError):
            raise self._busy()
        finally:
            # Unconditional: this also covers the timeout path and a client
            # that disconnected while queued. Leaking this counter would wedge
            # the gate shut for every later request.
            self.waiting -= 1
        self.in_flight += 1
        try:
            yield
        finally:
            self.in_flight -= 1
            self._sem.release()

    async def run(self, fn, *args, **kwargs):
        """Run a blocking turn off the event loop, under the gate."""
        async with self.slot():
            return await asyncio.to_thread(fn, *args, **kwargs)

    @asynccontextmanager
    async def exclusive(self):
        """Drain every permit so no chat turn is in flight."""
        async with self._drain_lock:
            acquired = 0
            try:
                for _ in range(self.limit):
                    await self._sem.acquire()
                    acquired += 1
                yield
            finally:
                for _ in range(acquired):
                    self._sem.release()


_chat_runner = ChatTurnRunner(_TURN_LIMIT, _TURN_QUEUE_MAX, _TURN_QUEUE_TIMEOUT)


async def _chat_turn(*args, **kwargs):
    """Run chatbot.chat off the event loop, under the turn gate."""
    async with _chat_runner.slot():
        intent, response, confidence, model_used, nlu_data = await asyncio.to_thread(
            chatbot.chat, *args, **kwargs,
        )
        nlu_data = dict(nlu_data or {})
        nlu_data["_model_version_id"] = chat_logger.model_version_for(model_used)
        return intent, response, confidence, model_used, nlu_data


@app.post("/chat", response_model=ChatResponse, tags=["Chat"],
          responses={400: {"description": "Message cannot be empty"}})
async def chat_endpoint(request: ChatRequest, http_request: Request):
    """
    Send a message to the chatbot (Hierarchical Hybrid Model).

    Uses Naive Bayes first (fast), falls back to Neural Network if uncertain.

    Request:
        message (str): User's question or input
        user_id (str, optional): Track conversation per user
        session_id (str, optional): Track conversation per session

    Returns:
        response (str): Chatbot's response
        intent (str): Classified intent
        confidence (float): Confidence score (0-1)
    """
    if not request.message or not request.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    # Rate-limit by session_id (so a single tab can't hammer us) with a
    # client-IP fallback for sessionless callers. Raises 429 when exceeded.
    _enforce_chat_limits(request.session_id, http_request)

    if request.intent_hint is not None or request.intent_args is not None:
        internal_key = os.getenv("INTERNAL_KEY", "")
        provided = http_request.headers.get("X-Internal-Key", "")
        if not (internal_key and secrets.compare_digest(provided, internal_key)):
            raise HTTPException(
                status_code=403,
                detail="intent_hint requires a valid X-Internal-Key header",
            )

    # Measure response time
    start_time = time.time()
    # The gates below may rewrite request.message (profanity sanitize, campus
    # grounding); keep the user's original for the audit log.
    original_message = request.message

    # Safety screen — runs before the MCP bridges and the intent tiers so no
    # path answers an abusive/threatening message cheerfully (the Nonsense/
    # Scope gates only guard the LLM tier). See docs/moderation_plan.md.
    block, request.message = await _safety_screen(request.message, request.session_id)
    if block:
        return await _short_circuit_response(request, original_message, start_time, **block)

    # Agentic workflow tier (Tier 5.5) — stateful, tool-executing conversations
    # (e.g. booking an advising appointment). Runs AFTER safety (so an abusive
    # or self-harm message mid-workflow is still caught first) but BEFORE campus
    # context and the MCP/NLU tiers: an active workflow owns the turn, and a
    # trigger phrase starts one. No-op unless AGENTIC_WORKFLOWS_ENABLED=1.
    # See docs/agentic_workflows_poc.md.
    wf_key = request.session_id or request.user_id
    wf_turn = await _workflows.dispatch(wf_key, request.message)
    if wf_turn is not None:
        return await _short_circuit_response(
            request, original_message, start_time,
            text=wf_turn.text,
            intent="action_book_advising",
            source=ResponseSource.WORKFLOW,
            model_used="Workflow (Tier 5.5)",
            suggestions=wf_turn.suggestions,
        )

    # Campus context — CvSU has 11 campuses; "where is the campus located?"
    # is ambiguous. Remember the session's campus, clarify when unknown
    # (suggestions become clickable campus chips), and rewrite follow-ups to
    # carry the campus so intents/charter-RAG/LLM retrieve the right one.
    campus_routing = _campus.resolve(
        request.session_id or request.user_id, request.message
    )
    if campus_routing.action == "clarify":
        return await _short_circuit_response(
            request, original_message, start_time,
            text=_campus.CLARIFY_TEXT,
            intent="campus_disambiguation",
            source=ResponseSource.FALLBACK,
            model_used="CampusContext (clarify)",
            suggestions=_campus.CLARIFY_SUGGESTIONS,
        )
    campus_grounded = campus_routing.action in ("augment", "answer_pending")
    if campus_grounded:
        # A canned intent answer would drop the campus the rewrite added —
        # send these to the deep tiers (charter RAG + LLM) instead.
        request.message = campus_routing.message

    # Campus directory — "where is CvSU <satellite campus>?" answers from the
    # charter's official contact table (api/campus_directory.py), never from
    # retrieval: the charter's per-campus sections rank cover pages (title
    # text, no address) above anything useful, and the only campus map is
    # Indang's. Main-campus asks stay with the cascade — the campus_location
    # intent has the richer answer plus the map card.
    if _campus_directory.is_directory_turn(request.message, campus_routing.campus):
        text, info = _campus_directory.build_answer(campus_routing.campus)
        return await _short_circuit_response(
            request, original_message, start_time,
            text=text,
            intent="campus_location",
            source=ResponseSource.CAMPUS_DIRECTORY,
            model_used="CampusDirectory (charter contact table)",
            suggestions=_campus_directory.SUGGESTIONS,
            cards=[
                DirectoryCard(
                    office=info.display_name,
                    location=info.address,
                    email=info.email,
                    phone=info.phone,
                )
            ],
        )

    # AIS MCP short-circuit — if the query looks like a finance/accounting
    # lookup (DV name, budget balance, RAPAL/RAOD report, UACS lookup),
    # answer it from the AIS MCP server instead of the student-facing NLU.
    # On transient AIS failure (timeout/transport error), `failure_note` is
    # set and we fall back to NLU with a discreet annotation prepended —
    # better UX than dumping a stack trace into the chat bubble.
    # FENCE: finance (AIS) and HR/DTR run ONLY for an authenticated internal
    # user. Anonymous callers get None -> both short-circuits are skipped and the
    # student NLU answers, so the public surface can never reach internal tools.
    internal_user = _internal_identity(http_request)
    ais_reply = await _try_ais(
        request.message,
        session_id=request.session_id,
        intent_hint=request.intent_hint,
        intent_args=request.intent_args,
    ) if internal_user else None
    ais_dv_card: Optional[DvCard] = None
    ais_failure_note: Optional[str] = None
    ais_context_set: Optional[Dict[str, Any]] = None
    ais_table: Optional[Dict[str, Any]] = None
    ais_suggestions: Optional[List[str]] = None
    if ais_reply is not None and ais_reply.get("text") is not None:
        ais_dv_card = DvCard(**ais_reply["dv_card"]) if ais_reply.get("dv_card") else None
        ais_context_set = ais_reply.get("context_set")
        ais_table = ais_reply.get("table")
        ais_suggestions = ais_reply.get("suggestions") or None
        intent, response, confidence, model_used, nlu_data = (
            "ais_mcp", ais_reply["text"], 1.0, "ais_mcp", {},
        )
    else:
        if ais_reply is not None:
            ais_failure_note = ais_reply.get("failure_note")
        # Connectors MCP short-circuit — university-services lookups (helpdesk
        # ticket tracking, course-catalog queries) served by the shared
        # read-only diwa-connectors server. Runs only when AIS didn't handle
        # the turn, so the two bridges are mutually exclusive and the table /
        # suggestions slots below are owned by whichever one answered.
        conn_reply = await _try_connectors(request.message, session_id=request.session_id)
        if conn_reply is not None and conn_reply.get("text") is not None:
            ais_table = conn_reply.get("table")
            ais_suggestions = conn_reply.get("suggestions") or None
            intent, response, confidence, model_used, nlu_data = (
                "connectors_mcp", conn_reply["text"], 1.0, "connectors_mcp", {},
            )
        else:
            if conn_reply is not None and not ais_failure_note:
                ais_failure_note = conn_reply.get("failure_note")
            # HR / DTR short-circuit — attendance / Daily Time Record queries,
            # served by the cvsu-hr MCP server. Runs only when HR_MCP_ENABLED=1
            # (off by default; DPA-sensitive, never on an anonymous surface) and
            # when neither AIS nor connectors handled the turn.
            hr_reply = await _try_hr(
                request.message, session_id=request.session_id,
                acting_user=internal_user,
            ) if internal_user else None
            if hr_reply is not None and hr_reply.get("text") is not None:
                ais_table = hr_reply.get("table")
                ais_suggestions = hr_reply.get("suggestions") or None
                intent, response, confidence, model_used, nlu_data = (
                    "hr_mcp", hr_reply["text"], 1.0, "hr_mcp", {},
                )
            else:
                intent, response, confidence, model_used, nlu_data = await _chat_turn(
                    request.message,
                    user_id=request.user_id,
                    session_id=request.session_id,
                    skip_intents=campus_grounded,
                    campus=campus_routing.campus,
                    language=request.language,
                )
                if ais_failure_note:
                    response = f"{ais_failure_note}\n\n{response}"

    response_time_ms = (time.time() - start_time) * 1000

    # Log the chat — record the user's ORIGINAL text, not the gate-rewritten
    # message (sanitized profanity / campus-grounded), so the moderation and
    # audit trail reflects what was actually sent.
    message_id = await _log_chat(
        user_id=request.user_id or "anonymous",
        user_message=original_message,
        bot_response=response,
        intent=intent,
        confidence=confidence,
        model_used=model_used,
        model_version_id=nlu_data.get("_model_version_id"),
        session_id=request.session_id,
        response_time_ms=response_time_ms,
        device_id=request.device_id,
        device_class=request.device_class,
    )

    # Logged verbatim above (audit trail); redacted for display. The summary
    # is drawn from the redacted prose; only `text` gets display structuring.
    response = _redact_office_phones(response, intent)

    cards, context, hint = _build_attachments(
        message=request.message,
        intent=intent,
        ais_dv_card=ais_dv_card,
        ais_table=ais_table,
        ais_context_set=ais_context_set,
        campus=campus_routing.campus,
        place_id=nlu_data.get("place_id"),
    )
    source, refusal_reason = _classify_source(model_used)

    # Per-intent grounding — surfaced structurally in `sources`, NOT appended to
    # the display text. Appending it too printed the same citation twice in one
    # reply: once as a full-size paragraph inside the bubble and again in the
    # citation chip the UI renders from `sources`. `sources` is the better of
    # the two — it carries the section, the office and a page-level deep link,
    # and a renderer can style it as a footnote instead of as body prose.
    _, sources = _intent_grounding_for(intent, source)
    display_text = _format_display_text(response)

    return ChatResponse(
        message_id=message_id,
        user_id=request.user_id,
        session_id=request.session_id,
        text=display_text,
        summary=_extract_summary(response),
        intent=intent,
        confidence=confidence,
        source=source,
        refusal_reason=refusal_reason,
        cards=cards,
        context=context,
        # NLU-tier suggestions (P2-8 disambiguation chips) share the slot the
        # MCP bridges use; the bridges win when both are present since a
        # bridge-handled turn never reaches the NLU cascade anyway.
        suggestions=ais_suggestions or nlu_data.get("suggestions") or [],
        display_hint=hint,
        sources=sources,
    )

@app.get("/intents", tags=["Intents"])
async def get_intents():
    """Get list of all available intent categories."""
    intents = chatbot.get_all_intents()
    return {
        "total_intents": len(intents),
        "intents": intents
    }


@app.get("/ais_mcp_stats", tags=["Admin"], dependencies=[Depends(require_admin)])
async def ais_mcp_stats():
    """Per-tool call counts, p50/p95 latency, error rate, and circuit-breaker
    status for the AIS MCP bridge. In-memory aggregates only — no persistence.
    Gated by `X-Admin-Pin` (matches DASHBOARD_PIN)."""
    snapshot = _ais_metrics_snapshot()
    snapshot["sessions"] = {"active_ais_logins": _ais_auth.session_count()}
    return snapshot


@app.get("/connectors_mcp_stats", tags=["Admin"], dependencies=[Depends(require_admin)])
async def connectors_mcp_stats():
    """Routing counts (regex vs LLM), per-tool call/ok counts, and transport
    failures for the connectors MCP bridge. In-memory aggregates only.
    Gated by `X-Admin-Pin` (matches DASHBOARD_PIN)."""
    return _connectors_metrics_snapshot()


# ─────────────────────────────────────────────────────────────────────────────
# Admin LLM toggle — switch which model answers, at runtime, no restart.
# ─────────────────────────────────────────────────────────────────────────────


class LlmToggleRequest(BaseModel):
    provider: Literal["ollama", "openai", "localai", "claude", "none"]
    model: Optional[str] = None  # e.g. "llama3.2:3b", "qwen3:8b", "claude-haiku-4-5"


async def _ollama_local_models() -> List[str]:
    """Best-effort list of locally pulled Ollama models (for a UI dropdown)."""
    import httpx

    from .llm_defaults import ollama_base_url

    base = ollama_base_url()
    try:
        async with httpx.AsyncClient(timeout=3.0) as http:
            resp = await http.get(f"{base}/api/tags")
            resp.raise_for_status()
            return sorted(m.get("name", "") for m in resp.json().get("models", []))
    except Exception:
        return []


async def _openai_compat_models() -> List[str]:
    """Best-effort list of the models an OpenAI-compatible server (llama-server,
    LM Studio, LocalAI) exposes at GET {OPENAI_BASE_URL}/models — the ids to
    POST back as provider=openai. Empty unless that provider is configured."""
    import httpx

    from .llm_defaults import OPENAI_COMPAT_PROVIDERS, openai_base_url, openai_headers

    if chatbot.llm_provider not in OPENAI_COMPAT_PROVIDERS and not os.getenv("OPENAI_BASE_URL"):
        return []
    try:
        async with httpx.AsyncClient(timeout=3.0) as http:
            resp = await http.get(f"{openai_base_url()}/models", headers=openai_headers())
            resp.raise_for_status()
            return sorted(m.get("id", "") for m in resp.json().get("data", []))
    except Exception:
        return []


_LOGS_DASHBOARD_HTML = Path(__file__).resolve().parent.parent / "web" / "logs_dashboard.html"


@app.get("/admin/logs", tags=["Admin"], include_in_schema=False)
async def logs_dashboard():
    """Serve the logs dashboard HTML from the API origin.

    Not PIN-gated: the page is a static shell with no secrets, and browsers
    can't attach the `X-Admin-Pin` header on a plain navigation. Serving it
    same-origin means the data endpoints (all still PIN-gated) need no CORS
    exception — open http://<api-host>/admin/logs and enter the PIN in-page.
    """
    if not _LOGS_DASHBOARD_HTML.exists():
        raise HTTPException(status_code=404, detail="Dashboard not found")
    return FileResponse(_LOGS_DASHBOARD_HTML, media_type="text/html")


# Conservative shapes for values taken from proxy headers — a scheme we will
# put in a link, and a host[:port]. Anything else is ignored in favour of what
# the ASGI scope reports.
_FWD_SCHEME_RE = re.compile(r"^https?$")
_FWD_HOST_RE = re.compile(r"^[A-Za-z0-9.\-]+(:\d{1,5})?$")


def _public_origin(request: Request) -> str:
    """The origin a browser would use to reach this API.

    `request.base_url` is not enough behind a TLS-terminating proxy: uvicorn
    only honours X-Forwarded-* from `forwarded_allow_ips` (default 127.0.0.1),
    and in a container the proxy is never 127.0.0.1 — so base_url reports
    `http` while the page is served over `https`, and the browser blocks the
    citation link as mixed content. Reading the headers here fixes the link
    without loosening uvicorn's proxy trust globally, which would also change
    which IP the rate limiter throttles on.

    Trusting a client header is safe *here* specifically because the origin is
    request-scoped: a forged X-Forwarded-Proto only alters the links in the
    reply to that same request.
    """
    base = urlsplit(str(request.base_url))
    scheme = request.headers.get("x-forwarded-proto", "").split(",")[0].strip().lower()
    host = request.headers.get("x-forwarded-host", "").split(",")[0].strip()
    if not _FWD_SCHEME_RE.match(scheme):
        scheme = base.scheme
    if not _FWD_HOST_RE.match(host):
        host = base.netloc
    # base.path carries root_path, so a sub-path mount keeps working.
    return f"{scheme}://{host}{base.path}"


@app.middleware("http")
async def _bind_charter_origin(request: Request, call_next):
    """Tell charter_pages which origin is serving this request, so a charter
    citation deep-links this API's own copy of the PDF with no configuration.

    Set before `call_next` so the downstream task inherits it (contexts are
    copied when a task is spawned, so it propagates down but not back up), and
    `asyncio.to_thread` carries it into the worker thread that renders the
    reply. Request-scoped on purpose — see charter_pages._request_origin.
    """
    _charter_pages.set_request_origin(_public_origin(request))
    return await call_next(request)


# HEAD is declared explicitly: FastAPI's @app.get registers GET alone (plain
# Starlette would add HEAD for you), and link checkers, proxies and uptime
# monitors HEAD a document URL before fetching it — a 405 there reads as a
# broken citation.
@app.api_route("/sources/citizens-charter.pdf", methods=["GET", "HEAD"], tags=["Sources"])
async def citizens_charter_pdf():
    """The Citizens' Charter itself, so a citation can be checked.

    Every charter citation names a page; without the document behind it the
    reader has nowhere to go. Served from this origin (rather than linked off
    to a third party) so the page a citation points at is the exact edition the
    answer was drawn from, and so the deep link `…/citizens-charter.pdf#page=N`
    lands on that page.

    Public and unauthenticated on purpose — it is a published government
    transparency document (RA 11032), identical to the copy on cvsu.edu.ph.
    `inline` so browsers open it at the fragment instead of downloading it.
    """
    if not _charter_pages.pdf_available():
        # Ships via .dockerignore's allow-list; a 404 here means the build
        # dropped it, which is also why CHARTER_PDF_URL is opt-in.
        raise HTTPException(status_code=404, detail="Charter PDF not available")
    return FileResponse(
        _charter_pages.PDF_PATH,
        media_type="application/pdf",
        headers={
            "Content-Disposition": 'inline; filename="cvsu-citizens-charter.pdf"',
            # Immutable for a given edition; a new edition changes the file.
            "Cache-Control": "public, max-age=604800",
        },
    )


@app.get("/admin/tier_disagreements", tags=["Admin"], dependencies=[Depends(require_admin)])
async def tier_disagreements(
    days: Annotated[int, Query(ge=1, le=365)] = 7,
    limit: Annotated[int, Query(ge=1, le=5000)] = 500,
):
    """The P1-5 arbitration review queue: turns where a confident NB answer was
    escalated (margin too thin / retrieval disagreed) or the NN would have
    overridden NB. The weekly triage input for retraining and threshold tuning.
    Gated by `X-Admin-Pin`."""
    rows = await asyncio.to_thread(chat_logger.get_tier_disagreements, days, limit)
    return {"count": len(rows), "window_days": days, "disagreements": rows}


@app.get("/admin/moderation", tags=["Admin"], dependencies=[Depends(require_admin)])
async def moderation_stats():
    """SafetyGate counters per category + the last 20 flagged messages
    (truncated), plus the repeat-abuse cooldown config/active count and whether
    PII masking is on. Gated by `X-Admin-Pin`."""
    return _safety.snapshot()


@app.get("/admin/anti_patterns", tags=["Admin"], dependencies=[Depends(require_admin)])
async def anti_patterns_report(
    days: Annotated[int, Query(ge=1, le=3650)] = 30,
    limit: Annotated[int, Query(ge=1, le=5000)] = 2000,
):
    """Anti-pattern mining: cluster recent unanswered fallbacks, off-topic /
    homework refusals, safety trips, and low-confidence answers into emerging
    themes with representative examples — the input to the monthly "what intents
    to add / what lexicon gaps to close" loop. Self-harm is counted but never
    themed or quoted. Gated by `X-Admin-Pin`.

    The same report prints from the CLI: `python scripts/mine_anti_patterns.py`."""
    rows = await asyncio.to_thread(chat_logger.get_anti_pattern_rows, days, limit)
    report = _anti_patterns.build_report(rows)
    report["generated_at"] = datetime.now().isoformat()
    report["window_days"] = days
    return report


_START_TIME = time.time()


@app.get("/admin/status", tags=["Admin"], dependencies=[Depends(require_admin)])
async def admin_status():
    """Single-pane operational status across every subsystem — the brain tiers,
    the LLM tier + model, the two MCP bridges, moderation, and campus context.
    Gated by `X-Admin-Pin`. Each subsystem is best-effort: a failure in one
    reports {error: ...} rather than sinking the whole call."""
    def _safe(fn, default=None):
        try:
            return fn()
        except Exception as exc:  # noqa: BLE001 — never let one subsystem 500 the status
            return {"error": exc.__class__.__name__}

    llm = _safe(chatbot.llm_status, {})
    return {
        "service": "DIWA API",
        # Deploy identity + gate state, formerly on the public /health payload —
        # moved here (P0-3) so confirming "which build is this server running"
        # still works from a browser, now with the PIN.
        "version": APP_VERSION,
        "build": APP_BUILD or None,
        "turn_gate": {
            "limit": _chat_runner.limit,
            "in_flight": _chat_runner.in_flight,
            "waiting": _chat_runner.waiting,
            "queue_max": _chat_runner.queue_max,
        },
        "uptime_seconds": int(time.time() - _START_TIME),
        "brain": {
            "classifier_ready": chatbot.nb_model is not None,
            "neural_net_ready": getattr(chatbot, "nn_model", None) is not None,
            "charter_rag": _safe(lambda: {
                "available": (idx := _charter_rag.get_index()) is not None,
                "chunks": len(idx._chunks) if idx else 0,
            }, {}),
            "intent_grounding": _safe(lambda: (
                gi.snapshot() if (gi := _intent_grounding.get_index()) else {"available": False}
            ), {}),
            # Whether citations can name a page's service and link to it —
            # `pdf_present` false or `pdf_url` null means text-only citations.
            "charter_pages": _safe(lambda: (
                cp.snapshot() if (cp := _charter_pages.get_index()) else {"available": False}
            ), {}),
            "usage": _safe(chatbot.get_usage_stats, {}),
        },
        "llm": {**llm, "second_opinion": os.getenv("SAFETY_LLM_SECOND_OPINION", "0") == "1"},
        "moderation": _safe(lambda: _safety.snapshot()["counts"], {}),
        "connectors_bridge": _safe(_connectors_metrics_snapshot, {}),
        "ais_bridge": _safe(_ais_circuit_status, {}),
        "campus_context": _safe(_campus.snapshot, {}),
    }


@app.get("/admin/llm", tags=["Admin"], dependencies=[Depends(require_admin)])
async def get_llm_config():
    """Which LLM tier is live (provider, model, reachable) plus the locally
    available Ollama and OpenAI-compatible models. Gated by `X-Admin-Pin`."""
    ollama_models, openai_models = await asyncio.gather(
        _ollama_local_models(), _openai_compat_models(),
    )
    return {
        **chatbot.llm_status(),
        "ollama_models": ollama_models,
        "openai_models": openai_models,
    }


@app.post("/admin/llm", tags=["Admin"], dependencies=[Depends(require_admin)])
async def set_llm_config(request: LlmToggleRequest):
    """Hot-swap the responding LLM: provider ollama/openai/localai/claude/none, optional
    model override. Also steers the AIS/connectors LLM routers (they follow
    LLM_PROVIDER per call). Takes effect on the next chat turn — no restart."""
    # set_llm probes the provider (up to 15s) — keep that off the event loop,
    # and take the turn lock so a toggle can't swap/None self.llm out from
    # under a chat turn running in another worker thread (mid-turn swap →
    # AttributeError → 500). Preserves the docstring's next-turn semantics.
    async with _chat_runner.exclusive():
        status = await asyncio.to_thread(chatbot.set_llm, request.provider, request.model)
        await asyncio.to_thread(chat_logger.refresh_model_versions)
    _logger.info(
        "admin llm toggle: provider=%s model=%s available=%s",
        status["provider"], status["model"], status["available"],
    )
    return status


@app.get("/admin/logs/tail", tags=["Admin"], dependencies=[Depends(require_admin)])
async def get_log_tail(lines: int = 200, grep: Optional[str] = None):
    """Recent in-process log lines (logging records + stdout prints — the
    "[4/5] LLM" init lines, tier decisions, warnings), readable from a browser
    when `docker logs` isn't reachable on the deployment host.

    (GET /admin/logs, without /tail, is the chat-logs dashboard HTML page —
    a different thing that predates this endpoint and owns that path.)

    `lines` caps how many of the newest lines return (max LOG_TAIL_LINES,
    default buffer 2000); `grep` filters case-insensitively BEFORE the cap
    (e.g. /admin/logs?grep=llm&lines=50). PIN-gated: lines can contain user
    messages. In-memory only — restart clears it."""
    tail = list(_LOG_TAIL)
    if grep:
        needle = grep.lower()
        tail = [ln for ln in tail if needle in ln.lower()]
    lines = max(1, min(lines, _LOG_TAIL.maxlen or 2000))
    tail = tail[-lines:]
    return {"count": len(tail), "capacity": _LOG_TAIL.maxlen, "lines": tail}


# ============================================================================
# AIS Auth Endpoints (Phase 2A, Wave 2)
# ============================================================================
# These let a Sevi web user log into AIS as their actual Frappe identity so
# subsequent write actions run with their SoD-relevant role instead of the
# shared bot identity. Tokens live in-memory keyed by `session_id` and
# evaporate on uvicorn restart.

class AuthLoginRequest(BaseModel):
    # Accepted but IGNORED. The server mints the session id itself and returns
    # it as an httpOnly cookie, so a client no longer supplies one — but an
    # older web build still sends it, and a required field would 422 every
    # login attempt during a rolling deploy.
    session_id: Optional[str] = None
    username: str
    password: str


class AuthLogoutRequest(BaseModel):
    # Optional for the same reason as the login/write models: the cookie is the
    # authority, so a browser has no session_id to send and a required field
    # would make signing out impossible for exactly the callers we now expect.
    session_id: Optional[str] = None


def _auth_handle(handler):
    """Translate AuthError into the standard FastAPI HTTPException pattern.
    Keeps the endpoint bodies trivial."""
    async def wrapper(*args, **kwargs):
        try:
            return await handler(*args, **kwargs)
        except _ais_auth.AuthError as exc:
            raise HTTPException(status_code=exc.status_code, detail=exc.message) from exc
    return wrapper


# The AIS session id is a bearer for the user's OAuth token, so it lives in an
# httpOnly cookie: minted server-side at login, never readable by JavaScript,
# and never echoed in a response body or a URL.
_AIS_COOKIE = "sevi_ais"


def _ais_sid(request: Request, fallback: Optional[str] = None) -> str:
    """Resolve the AIS session: cookie first, then an explicit value.

    The fallback keeps non-browser callers (and any web build still in flight
    during a deploy) working; browsers send the cookie and never see the value.
    """
    return (request.cookies.get(_AIS_COOKIE, "") or (fallback or "")).strip()


@app.post("/auth/login", tags=["AIS Auth"])
async def auth_login(request: AuthLoginRequest, http_request: Request):
    """Exchange CvSU credentials for an AIS OAuth session.

    Returns the user's identity claims only. The session id is minted
    server-side and returned as an httpOnly cookie — never in the body, so it
    cannot be read by script or captured from a log.
    """
    sid, identity = await _auth_handle(_ais_auth.login)(
        request.username, request.password,
    )
    response = JSONResponse(identity)
    response.set_cookie(
        _AIS_COOKIE, sid,
        httponly=True,
        secure=_ADMIN_COOKIE_SECURE,
        samesite="strict",
        path="/",
    )
    return response


@app.post("/auth/logout", tags=["AIS Auth"])
async def auth_logout(request: AuthLogoutRequest, http_request: Request):
    """Drop the cached AIS token for this session. Idempotent — succeeds
    even if there was no session to begin with."""
    await _ais_auth.logout(_ais_sid(http_request, request.session_id))
    response = JSONResponse({"ok": True})
    response.delete_cookie(_AIS_COOKIE, path="/")
    return response


@app.get("/auth/whoami", tags=["AIS Auth"])
async def auth_whoami(
    http_request: Request,
    x_sevi_session: Annotated[Optional[str], Header()] = None,
    session_id: Optional[str] = None,
):
    """Identity snapshot for an active session. Returns {"logged_in": false}
    when no session is cached so the frontend can decide whether to show
    the login modal — no error, just a fact.

    The session id is read from the `X-Sevi-Session` HEADER, never the URL.
    session_id is a bearer capability for the cached AIS token (possession of it
    authorizes /ais/write financial actions), so it must not travel in the query
    string, where the tunnel/nginx access log would persist it (CWE-598). The
    `session_id` query param is a DEPRECATED fallback retained only so an
    in-flight older web build doesn't spuriously log the user out mid-deploy;
    current clients send the header.
    """
    sid = _ais_sid(http_request, x_sevi_session or session_id)
    if not sid:
        return {"logged_in": False}
    snapshot = await _ais_auth.whoami(sid)
    if snapshot is None:
        return {"logged_in": False}
    return {"logged_in": True, **snapshot}


# ============================================================================
# AIS Write Endpoint (Phase 2A, Wave 2)
# ============================================================================
# Out-of-band entry point for confirmed DV write actions from the Sevi web
# UI. Distinct from /chat by design — /chat is anonymous and free-form;
# /ais/write requires an authenticated session AND a UI-driven confirm
# modal AND a tool-specific arg shape. There is intentionally NO natural-
# language path to writes anywhere.

_WRITE_ACTION_TOOL_MAP: Dict[str, str] = {
    "approve_dv":    "approve_dv",
    "post_dv":       "post_dv",
    "cancel_dv":     "cancel_dv",
    "set_dv_status": "set_dv_status",
}


class AisWriteRequest(BaseModel):
    # Optional: the httpOnly cookie is the authority now (_ais_sid resolves it
    # first). Still accepted so non-browser callers, and any web build that
    # predates the cookie, keep working.
    session_id: Optional[str] = None
    action: str                          # one of _WRITE_ACTION_TOOL_MAP keys
    name: str                            # DV name
    idempotency_key: str
    expected_modified: Optional[str] = None
    reason: Optional[str] = None         # cancel_dv requires this
    new_status: Optional[str] = None     # set_dv_status requires this


@app.post("/ais/write", tags=["AIS Write"])
async def ais_write(request: AisWriteRequest, http_request: Request):
    """Invoke an AIS write tool as the end user behind `session_id`.

    Steps:
      1. Resolve the session_id → cached AIS access token (refreshing if
         expiring). 401 if no session.
      2. Translate the action into the MCP tool name and assemble the
         tool's required args (incl. the hidden `__auth_token`).
      3. Call the MCP write tool. The MCP server enforces the kill switch
         (returning PILOT when off) and translates Frappe 403s into a
         clean FORBIDDEN response.
      4. Return the tool's response verbatim — the frontend treats `ok`
         as the success flag.
    """
    if request.action not in _WRITE_ACTION_TOOL_MAP:
        raise HTTPException(status_code=400, detail=f"Unknown action: {request.action}")

    # 1. Token resolution (may refresh). The session comes from the httpOnly
    # cookie, so the value that authorizes a financial write is one the page's
    # JavaScript never held and the client never chose.
    try:
        token = await _ais_auth.get_user_token(_ais_sid(http_request, request.session_id))
    except _ais_auth.AuthError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.message) from exc

    # 2. Assemble args. Drop None values so the tool's schema validation
    # doesn't complain about extra fields it doesn't expect for THIS action.
    args: Dict[str, Any] = {
        "name": request.name,
        "confirm": True,                  # /ais/write is invoked from a confirm modal — implicit
        "idempotency_key": request.idempotency_key,
        "__auth_token": token,
    }
    if request.expected_modified:
        args["expected_modified"] = request.expected_modified
    if request.reason and request.action == "cancel_dv":
        args["reason"] = request.reason
    if request.new_status and request.action == "set_dv_status":
        args["new_status"] = request.new_status

    # 3. Call. Three failure modes to distinguish:
    #    - ToolCallError: Frappe rejected the action (validation, SoD, stale
    #      lock, missing certs). Return a structured non-200 response with
    #      the sanitized message so the modal can show it.
    #    - Other Exception: transport / SDK / circuit-open → 503.
    #    - Success: forward the tool's response verbatim.
    tool_name = _WRITE_ACTION_TOOL_MAP[request.action]
    try:
        result = await _ais_call_tool(tool_name, args)
    except _AisToolCallError as exc:
        # ToolCallError = MCP reachable, Frappe said no. Sanitize the
        # message (strips the "Error calling X: TypeName: " wrapper and
        # extracts the meaningful exception text from Frappe's JSON body).
        user_text, treat_as_unreachable = _ais_sanitize_tool_error(str(exc))
        if treat_as_unreachable:
            _logger.exception("ais_write tool=%s name=%s reason=server_5xx", tool_name, request.name)
            raise HTTPException(status_code=503, detail="AIS is temporarily unreachable — try again.") from exc
        _logger.info("ais_write tool=%s name=%s reason=tool_rejected msg=%s",
                     tool_name, request.name, user_text[:200])
        return {"ok": False, "error_code": "REJECTED", "message": user_text}
    except Exception as exc:  # noqa: BLE001 — transport/SDK/circuit failure
        _logger.exception("ais_write tool=%s name=%s reason=transport", tool_name, request.name)
        raise HTTPException(status_code=503, detail="AIS write failed — try again.") from exc

    return result


# ============================================================================
# Campus Map Endpoints
# ============================================================================

@app.get("/map", tags=["Map"])
async def get_campus_map():
    """Return the full set of campus places, the gate position, and the SVG viewBox.

    Edit `api/campus_places.py` server-side to change labels, geometry, walk
    times, or directions without recompiling the frontend.
    """
    return _campus_map_payload()

@app.get("/map/coords", tags=["Map"])
async def get_map_coords():
    """Return all current effective marker coords + just the override layer.

    The `coords` block is what /map serves (defaults merged with admin
    overrides). The `overrides` block is the DB (or JSON-file) overrides.
    """
    payload = _campus_map_payload()
    coords = {
        p.place_id: {"x": p.x, "y": p.y}
        for p in payload["places"]
        if p.x is not None and p.y is not None
    }
    return {"coords": coords, "overrides": _list_coord_overrides()}


@app.put("/map/coords", tags=["Map"], dependencies=[Depends(require_admin)])
async def put_map_coords(body: CoordsUpdate):
    """Admin: persist marker (x, y) edits to DB (and JSON fallback).

    Existing overrides are merged with the body so partial updates don't
    overwrite untouched entries. Bad place_ids are silently ignored.
    """
    payload = {pid: {"x": e.x, "y": e.y} for pid, e in body.coords.items()}
    applied = _save_coord_overrides(payload)
    return {"status": "saved", "applied": applied, "overrides": _list_coord_overrides()}


@app.delete("/map/coords", tags=["Map"], dependencies=[Depends(require_admin)])
async def delete_map_coords():
    """Admin: clear all marker overrides from DB and JSON file."""
    _reset_coord_overrides()
    return {"status": "reset"}


@app.get("/map/waypoints", tags=["Map"])
async def get_map_waypoints():
    """Return waypoint overrides from DB (falls back to JSON file).
    Frontend merges these onto its bundled WAYPOINTS graph for routing.
    """
    return {"overrides": _list_waypoint_overrides()}


@app.put("/map/waypoints", tags=["Map"], dependencies=[Depends(require_admin)])
async def put_map_waypoints(body: WaypointsUpdate):
    """Admin: persist waypoint (x, y) edits to DB and JSON file.
    Entries for custom waypoints may include a `neighbors` array."""
    payload: Dict[str, Dict[str, Any]] = {}
    for wid, e in body.coords.items():
        entry: Dict[str, Any] = {"x": e.x, "y": e.y}
        if e.neighbors is not None:
            entry["neighbors"] = list(e.neighbors)
        payload[wid] = entry
    count = _save_waypoint_overrides(payload)
    return {"status": "saved", "overrides": _list_waypoint_overrides(), "total": count}


@app.delete("/map/waypoints", tags=["Map"], dependencies=[Depends(require_admin)])
async def delete_map_waypoints():
    """Admin: clear all waypoints from DB and JSON file."""
    _reset_waypoint_overrides()
    return {"status": "reset"}


@app.delete("/map/waypoints/{waypoint_id}", tags=["Map"], dependencies=[Depends(require_admin)])
async def delete_map_waypoint(waypoint_id: str):
    """Admin: drop a single waypoint from DB and JSON file."""
    removed = _delete_waypoint_override(waypoint_id)
    return {"status": "deleted" if removed else "not_found", "waypoint_id": waypoint_id}


# ---------------------------------------------------------------------------
# Custom markers — admin-created buildings beyond the canonical 48.
# ---------------------------------------------------------------------------

@app.get("/map/custom_markers", tags=["Map"])
async def get_custom_markers():
    """Return custom markers from DB (falls back to JSON file)."""
    return {"markers": _list_custom_markers()}


@app.post("/map/custom_markers", tags=["Map"], dependencies=[Depends(require_admin)])
async def post_custom_marker(body: CustomMarkerCreate):
    """Admin: add or update a custom marker in DB and JSON file."""
    try:
        entry = _upsert_custom_marker(body.model_dump(exclude_none=True))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return {"status": "saved", "marker": entry, "markers": _list_custom_markers()}


@app.delete("/map/custom_markers/{marker_id}", tags=["Map"], dependencies=[Depends(require_admin)])
async def remove_custom_marker(marker_id: str):
    """Admin: delete a custom marker from DB and JSON file."""
    removed = _delete_custom_marker(marker_id)
    return {"status": "deleted" if removed else "not_found", "marker_id": marker_id}


@app.get("/map/{place_id}", response_model=PlaceMeta, tags=["Map"],
         responses={404: {"description": "Place not found"}})
async def get_place(place_id: str):
    """Return canonical metadata for a single campus place."""
    if not _has_place(place_id):
        raise HTTPException(status_code=404, detail=f"Place '{place_id}' not found")
    return _build_place_meta(place_id)

@app.get("/intents/{intent_tag}", tags=["Intents"],
         responses={404: {"description": "Intent not found"}})
async def get_intent(intent_tag: str):
    """Get details about a specific intent."""
    details = chatbot.get_intent_details(intent_tag)

    if not details:
        raise HTTPException(status_code=404, detail=f"Intent '{intent_tag}' not found")

    return details

@app.get("/model/info", response_model=ModelInfo, tags=["Model"])
async def model_info():
    """Get sanitized model information (no internal details exposed)."""
    return ModelInfo(
        total_intents=chatbot.total_intents,
    )

@app.post("/model/reload", tags=["Model"], dependencies=[Depends(require_admin)])
async def reload_model():
    """Hot-reload all model artifacts from disk without restarting the server."""
    global chatbot

    def _rebuild():
        # TF/joblib loads plus a synchronous LLM probe (up to 15s) — multi-second
        # work that must stay off the event loop, and behind the turn lock so the
        # swap never lands mid-chat-turn.
        new_bot = HybridChatbot(
            model_dir=MODEL_DIR,
            responses_path=os.path.join(MODEL_DIR, "responses_map.json")
        )
        # Retrieval tiers read the same artifacts (intents DB, site corpus) —
        # rebuild them so a retrain/resync is picked up in the same call.
        _intent_retrieval.reload_index()
        _site_rag.reload_index()
        _intent_grounding.reload_index()
        # data/charter_structure.json is meant to be hand-edited when the OCR
        # mangled a heading — picking it up here is what makes that a one-call
        # fix instead of a redeploy.
        _charter_pages.reload_index()
        # Re-wire the P1-5 disagreement sink — a fresh HybridChatbot starts
        # with disagreement_logger=None and would silently stop persisting
        # the review queue after a hot reload.
        new_bot.disagreement_logger = chat_logger.log_tier_disagreement
        return new_bot

    async with _chat_runner.exclusive():
        old_bot = chatbot
        chatbot = await asyncio.to_thread(_rebuild)
        # Stop the REPLACED bot's llm-keep-warm heartbeat, and only after the
        # rebuild succeeded — stopping before _rebuild would leave a still-live
        # old bot with a dead heartbeat if the rebuild throws. Without this the
        # old thread's closure pins the entire previous chatbot (TF NN + NB
        # pipeline + response maps) in RAM forever, one leaked instance per
        # reload, while its zombie ticks contend for the single Ollama slot.
        old_bot.stop_keep_warm()
    return {"status": "reloaded"}


@app.post("/admin/site_corpus/sync", tags=["Admin"], dependencies=[Depends(require_admin)])
async def sync_site_corpus():
    """Re-pull the official website into the site-RAG corpus and reindex.

    Fetches posts + pages (with metadata) from the portal named by
    SITE_CORPUS_URL via the WordPress REST API, rewrites docs/site_corpus.txt,
    and rebuilds the retrieval index. Gated by `X-Admin-Pin`."""
    try:
        stats = await asyncio.to_thread(_site_rag.sync_corpus)
    except Exception as exc:
        raise HTTPException(502, f"Site corpus sync failed: {exc}")
    # Off the loop like the sync above it: reload_index now builds the whole
    # index before swapping it in, so on the event loop it would stall every
    # other request for the duration of the build.
    index = await asyncio.to_thread(_site_rag.reload_index)
    stats["index_available"] = index is not None
    return stats

@app.get("/conversation/{user_id}", tags=["Conversation"],
         dependencies=[Depends(require_admin)])
async def get_conversation_history(user_id: str):
    """Get conversation history for a user."""
    # Snapshot under the chatbot's own history lock rather than the turn gate.
    # The requirement was never "no turn may run" — it was "don't serialize a
    # list a worker is appending to". Blocking every turn to read one session's
    # history was collateral damage from having a single lock; the narrow lock
    # gives the same guarantee without stalling chat. Off the event loop so a
    # contended lock can't stall the loop itself.
    history = await asyncio.to_thread(chatbot.snapshot_history, user_id)
    return {
        "user_id": user_id,
        "message_count": len(history),
        "conversation": history
    }

@app.delete("/conversation/{user_id}", tags=["Conversation"],
            dependencies=[Depends(require_admin)])
async def clear_conversation(user_id: str):
    """Clear conversation history for a user."""
    # drop_history pops under the history lock, so it cannot land between a
    # worker's move_to_end and its read — the KeyError this used to guard
    # against. Check-and-delete is one atomic step there, not two here.
    removed = await asyncio.to_thread(chatbot.drop_history, user_id)
    if removed:
        return {"status": "cleared", "user_id": user_id}
    return {"status": "no_history", "user_id": user_id}

_BATCH_MAX = int(os.getenv("BATCH_MAX", "20"))


@app.post("/batch", tags=["Chat"])
async def batch_chat(requests: List[ChatRequest], http_request: Request):
    """
    Process multiple chat requests in batch.

    Useful for integration with web apps that need multiple responses.

    Each sub-request spends from the SAME per-session/IP chat budget as /chat:
    unthrottled, /batch was a 20x compute amplifier that ran the full tier
    cascade behind the global turn lock for an anonymous caller.
    """
    if len(requests) > _BATCH_MAX:
        raise HTTPException(status_code=413, detail=f"Batch too large (max {_BATCH_MAX})")
    results = []
    for request in requests:
        # Same two tiers as /chat, so a batch cannot buy extra budget by varying
        # session_id across its sub-requests.
        _enforce_chat_limits(request.session_id, http_request)
        start_time = time.time()
        # Same front-door SafetyGate as /chat — /batch must not be an
        # unscreened second entrance for abusive/self-harm messages.
        original_message = request.message
        block, request.message = await _safety_screen(request.message, request.session_id)
        if block:
            results.append(await _short_circuit_response(request, original_message, start_time, **block))
            continue
        intent, response, confidence, model_used, nlu_data = await _chat_turn(
            request.message,
            user_id=request.user_id,
            session_id=request.session_id,
            language=request.language,
        )
        response_time_ms = (time.time() - start_time) * 1000

        # Log each message (original text — request.message may be sanitized)
        message_id = await _log_chat(
            user_id=request.user_id or "anonymous",
            user_message=original_message,
            bot_response=response,
            intent=intent,
            confidence=confidence,
            model_used=model_used,
            model_version_id=nlu_data.get("_model_version_id"),
            session_id=request.session_id,
            response_time_ms=response_time_ms,
            device_id=request.device_id,
            device_class=request.device_class,
        )

        # Logged verbatim above (audit trail); redacted for display. The summary
        # is drawn from the redacted prose; only `text` gets display structuring.
        response = _redact_office_phones(response, intent)

        cards, context, hint = _build_attachments(
            message=request.message,
            intent=intent,
            ais_dv_card=None,
            ais_table=None,
            ais_context_set=None,
            place_id=nlu_data.get("place_id"),
        )
        source, refusal_reason = _classify_source(model_used)

        # Structural citation only — see the note on the single-turn path.
        _, sources = _intent_grounding_for(intent, source)
        display_text = _format_display_text(response)

        results.append(ChatResponse(
            message_id=message_id,
            user_id=request.user_id,
            session_id=request.session_id,
            text=display_text,
            summary=_extract_summary(response),
            intent=intent,
            confidence=confidence,
            source=source,
            refusal_reason=refusal_reason,
            cards=cards,
            context=context,
            suggestions=nlu_data.get("suggestions") or [],
            display_hint=hint,
            sources=sources,
        ))
    return {"count": len(results), "results": results}

# ============================================================================
# Logging Endpoints
# ============================================================================

@app.get("/logs/user/{user_id}", tags=["Logging"], dependencies=[Depends(require_admin)])
async def get_user_logs(user_id: str, limit: Annotated[int, Query(ge=1, le=200)] = 50):
    """Get chat history for a specific user"""
    history = chat_logger.get_user_history(user_id, limit)
    return {
        "user_id": user_id,
        "message_count": len(history),
        "messages": history
    }

@app.get("/logs/session/{session_id}", tags=["Logging"], dependencies=[Depends(require_admin)])
async def get_session_logs(session_id: str):
    """Get all messages in a specific session"""
    history = chat_logger.get_session_history(session_id)
    return {
        "session_id": session_id,
        "message_count": len(history),
        "messages": history
    }

@app.get("/logs/recent", tags=["Logging"], dependencies=[Depends(require_admin)])
async def get_recent_logs(limit: Annotated[int, Query(ge=1, le=200)] = 20):
    """Get the most recent messages across all users (dashboard 'Messages' tab)."""
    limit = max(1, min(limit, 200))
    messages = chat_logger.get_recent_messages(limit)
    return {
        "count": len(messages),
        "messages": messages
    }

@app.get("/logs/intents", tags=["Logging"], dependencies=[Depends(require_admin)])
async def get_intent_logs():
    """Get statistics for all intents"""
    stats = chat_logger.get_intent_statistics()
    return {
        "total_intents": len(stats),
        "intents": stats
    }

@app.get("/logs/sessions", tags=["Logging"], dependencies=[Depends(require_admin)])
async def get_sessions_list(
    user_id: Optional[str] = None,
    limit: Annotated[int, Query(ge=1, le=200)] = 20,
):
    """Get list of sessions"""
    sessions = chat_logger.get_session_list(user_id, limit)
    return {
        "user_id": user_id,
        "session_count": len(sessions),
        "sessions": sessions
    }

@app.get("/logs/today", tags=["Logging"], dependencies=[Depends(require_admin)])
async def get_today_statistics():
    """Get today's chat statistics"""
    stats = chat_logger.get_today_stats()
    return stats

@app.get("/logs/devices", tags=["Logging"], dependencies=[Depends(require_admin)])
async def get_device_statistics(days: Annotated[int, Query(ge=1, le=365)] = 30):
    """Device-usage rollup: distinct devices, form factor, and orientation.

    Admin-gated like the rest of /logs — device_id is a persistent identifier
    and the breakdown is operational data, not a public metric.
    """
    return chat_logger.get_device_stats(days)

@app.get("/logs/search", tags=["Logging"], dependencies=[Depends(require_admin)])
async def search_logs(query: str, limit: Annotated[int, Query(ge=1, le=200)] = 20):
    """Search logs by message content"""
    results = chat_logger.search_logs(query, limit)
    return {
        "query": query,
        "results_count": len(results),
        "results": results
    }

@app.post("/logs/export/{user_id}", tags=["Logging"],
          dependencies=[Depends(require_admin)],
          responses={500: {"description": "Export failed"}})
async def export_user_logs(user_id: str):
    """Export all data for a user as JSON file.

    `user_id` lands in the output filename, so it is allowlisted here (400)
    before the logger's own hard guard sees it — a path-traversal id must not
    read as a generic 500 "Export failed".
    """
    if not _is_safe_user_id(user_id):
        raise HTTPException(status_code=400, detail="Invalid user_id")
    filepath = chat_logger.export_user_data(user_id)
    if filepath:
        return {"status": "success"}
    else:
        raise HTTPException(status_code=500, detail="Export failed")

@app.delete("/logs/cleanup", tags=["Logging"], dependencies=[Depends(require_admin)])
async def cleanup_old_logs(days: Annotated[int, Query(ge=1, le=3650)] = 30):
    """Delete logs older than specified days.

    `days` is floored at 1: a zero/negative window puts the retention cutoff in
    the future, which would delete the ENTIRE chat + feedback history.
    """
    deleted = chat_logger.cleanup_old_logs(days)
    return {
        "status": "success",
        "days": days,
        "deleted_entries": deleted,
        "message": f"Deleted {deleted} log entries older than {days} days"
    }

# ============================================================================
# Feedback Endpoints
# ============================================================================

def _extract_new_patterns(
    entries: List[Dict],
    intent_map: Dict[str, Any],
    existing_patterns: Dict[str, set],
) -> Dict[str, List[str]]:
    """Return new patterns derived from feedback entries, grouped by intent tag."""
    additions: Dict[str, List[str]] = defaultdict(list)
    for entry in entries:
        target = entry.get("suggested_intent")
        query = (entry.get("user_message") or "").strip()
        helpful = entry.get("helpful")
        rating = entry.get("rating")

        if not target and helpful is True and rating is not None and rating <= 3:
            target = entry.get("intent")

        if not target or not query or target not in intent_map:
            continue
        if query in existing_patterns[target]:
            continue

        intent_map[target]["patterns"].append(query)
        existing_patterns[target].add(query)
        additions[target].append(query)
    return additions


@app.post(
    "/feedback",
    tags=["Feedback"],
    responses={
        422: {"description": "rating must be an integer between 1 and 5"},
        500: {"description": "Failed to store feedback"},
    },
)
async def submit_feedback(request: FeedbackRequest):
    """
    Submit feedback for a bot response.

    Stores a rating, helpful flag, optional comment, and an optional
    suggested_intent correction for misclassified messages.
    Pass user_message when message_id is unavailable so the analyze
    endpoint can still extract training patterns.
    """
    if request.rating is not None and not (1 <= request.rating <= 5):
        raise HTTPException(status_code=422, detail="rating must be between 1 and 5")

    if request.reason is not None and request.reason not in _VALID_REASON_CODES:
        raise HTTPException(
            status_code=422,
            detail=f"reason must be one of {sorted(_VALID_REASON_CODES)}"
        )

    feedback_id = chat_logger.log_feedback(
        message_id=request.message_id,
        user_id=request.user_id,
        session_id=request.session_id,
        intent=request.intent,
        rating=request.rating,
        helpful=request.helpful,
        comment=request.comment,
        suggested_intent=request.suggested_intent,
        user_message=request.user_message,
        reason=request.reason,
    )

    if feedback_id is None:
        raise HTTPException(status_code=500, detail="Failed to store feedback")

    return {"status": "ok", "feedback_id": feedback_id}


@app.get("/feedback", tags=["Feedback"], dependencies=[Depends(require_admin)])
async def get_feedback(
    limit: Annotated[int, Query(ge=1, le=200)] = 100,
    helpful: Optional[bool] = None,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    intent: Optional[str] = None,
    min_rating: Optional[int] = None,
    max_rating: Optional[int] = None,
):
    """
    Retrieve feedback entries, joined with the original chat message.

    All filter parameters are optional and can be combined.
    """
    entries = chat_logger.get_feedback_entries(
        limit=limit,
        helpful=helpful,
        user_id=user_id,
        session_id=session_id,
        intent=intent,
        min_rating=min_rating,
        max_rating=max_rating,
    )
    return {"count": len(entries), "feedback": entries}


@app.get("/feedback/reasons", tags=["Feedback"])
async def get_feedback_reasons():
    """
    Return the structured reason taxonomy used by /feedback. Frontends should
    fetch this once and render chips/buttons so the codes stay in lockstep
    with the backend's allow-list.
    """
    return FEEDBACK_REASONS


@app.get("/feedback/stats", tags=["Feedback"], dependencies=[Depends(require_admin)])
async def get_feedback_stats():
    """
    Aggregated feedback statistics: overall totals, per-intent breakdown,
    lowest-rated intents, and the 10 most recent comments.
    """
    stats = chat_logger.get_feedback_stats()
    return stats


@app.get("/feedback/fallbacks", tags=["Feedback"], dependencies=[Depends(require_admin)])
async def get_feedback_fallbacks(limit: Annotated[int, Query(ge=1, le=200)] = 100):
    """
    Return recent messages that triggered the nlu_fallback intent.
    Useful for manually identifying missing training patterns.
    """
    examples = chat_logger.get_fallback_examples(limit=limit)
    return {"count": len(examples), "fallbacks": examples}


@app.post("/feedback/analyze", tags=["Feedback"],
          dependencies=[Depends(require_admin)],
          responses={500: {"description": "Operation failed"}})
async def analyze_feedback(request: FeedbackAnalyzeRequest):
    """
    Batch feedback analysis — identify misclassified utterances from stored
    feedback and optionally patch them back into the intent dataset.

    Workflow:
    1. Pull feedback entries matching the supplied filters.
    2. For each unhelpful or low-rated entry that carries a suggested_intent,
       add the original user_message as a new training pattern for that intent
       (deduplication is automatic).
    3. If apply=true, overwrite data/cavsu_intents.json (a timestamped backup
       is created first) and rebuild the SQLite intent database.
       If apply=false (default), write a preview file instead so you can
       review changes before committing.

    Returns a summary of how many patterns were added per intent.
    """
    entries = chat_logger.get_feedback_entries(
        limit=request.limit,
        helpful=request.helpful,
        user_id=request.user_id,
        session_id=request.session_id,
        intent=request.intent,
        min_rating=request.min_rating,
        max_rating=request.max_rating,
    )

    if not entries:
        return {
            "status": "no_data",
            "message": "No feedback entries matched the supplied filters.",
            "filters": request.model_dump(),
            "patterns_added": 0,
            "by_intent": {}
        }

    # Resolve paths relative to the project root (two levels up from api/)
    root = Path(__file__).resolve().parents[1]
    intents_path = root / "data" / "cavsu_intents.json"
    db_path = root / "data" / "cavsu_intents.db"

    if not intents_path.exists():
        raise HTTPException(status_code=500, detail="Intent dataset unavailable")

    raw = await asyncio.to_thread(intents_path.read_text, encoding="utf-8")
    intents_doc = json.loads(raw)

    intent_map: Dict[str, Any] = {i["tag"]: i for i in intents_doc["intents"]}
    existing_patterns: Dict[str, set] = {
        tag: set(i.get("patterns", [])) for tag, i in intent_map.items()
    }
    additions = _extract_new_patterns(entries, intent_map, existing_patterns)

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    result: Dict[str, Any] = {
        "run_id": run_id,
        "entries_analyzed": len(entries),
        "patterns_added": sum(len(v) for v in additions.values()),
        "by_intent": dict(sorted(additions.items())),
        "apply": request.apply,
    }

    if not additions:
        result["status"] = "no_changes"
        result["message"] = "No new patterns identified from the filtered feedback."
        return result

    if request.apply:
        backup_path = root / "data" / f"cavsu_intents.backup_{run_id}.json"
        original_raw = await asyncio.to_thread(intents_path.read_text, encoding="utf-8")
        await asyncio.to_thread(backup_path.write_text, original_raw, encoding="utf-8")
        updated = json.dumps(intents_doc, indent=2, ensure_ascii=False)
        await asyncio.to_thread(intents_path.write_text, updated, encoding="utf-8")

        # Rebuild the SQLite intent database
        try:
            import sys
            if str(root) not in sys.path:
                sys.path.insert(0, str(root))
            from intents_db import create_intents_database
            await asyncio.to_thread(
                create_intents_database,
                json_path=str(intents_path),
                db_path=str(db_path),
                recreate=True,
            )
            result["db_rebuilt"] = True
        except Exception as exc:
            result["db_rebuilt"] = False
            result["db_error"] = str(exc)

        result["status"] = "applied"
        result["restart_api_required"] = True
    else:
        preview_path = root / "data" / f"cavsu_intents_preview_{run_id}.json"
        preview_text = json.dumps(intents_doc, indent=2, ensure_ascii=False)
        await asyncio.to_thread(preview_path.write_text, preview_text, encoding="utf-8")
        result["status"] = "preview"
        result["message"] = "Dry-run complete. Set apply=true to commit changes."

    return result


# ============================================================================
# Topic recommendation (seasonal homepage cards)
# ============================================================================

@app.get("/topics/recommended", tags=["Topics"])
async def get_recommended_topics():
    """Return today's recommended topic tags, ranked.

    Filters against the active intent set so the homepage never recommends
    an intent that wouldn't actually answer. The frontend turns each tag
    into a TopicCard using its own catalog.
    """
    try:
        intents = chatbot.get_all_intents() if hasattr(chatbot, "get_all_intents") else []
    except Exception:
        intents = []
    return _recommend_topics(available_tags=intents)


# ============================================================================
# Admin: candidate intent sanitation (content moderation + training safety)
# ============================================================================

class CandidateIntent(BaseModel):
    """Payload for POST /admin/intents/sanitize."""
    tag: str
    patterns: List[str]
    responses: List[str]


def _predict_proba_dict(text: str) -> Dict[str, float]:
    """Run an arbitrary string through the loaded NB classifier and return
    a {tag: probability} map for collision detection."""
    nb = getattr(chatbot, "nb_model", None)
    if nb is None or not hasattr(nb, "pipeline"):
        return {}
    try:
        cleaned = nb._preprocess(text)
        proba = nb.pipeline.predict_proba([cleaned])[0]
        classes = list(nb.pipeline.classes_)
        return {tag: float(p) for tag, p in zip(classes, proba)}
    except Exception:
        return {}


class PinRequest(BaseModel):
    pin: str

@app.post("/admin/verify", tags=["Admin"])
async def verify_admin_pin(body: PinRequest, request: Request):
    """Exchange the dashboard PIN for an httpOnly admin session (rate-limited).

    The PIN is presented ONCE, here. Everything after this rides the cookie, so
    the shared secret never has to live in JavaScript-readable storage or be
    re-sent on each admin call.
    """
    client_ip = _client_ip(request)
    _check_rate_limit(client_ip)
    if not DASHBOARD_PIN:
        raise HTTPException(503, "Admin access not configured")
    if not _pin_matches(body.pin):
        _record_attempt(client_ip)
        raise HTTPException(401, "Invalid PIN")
    token = _admin_session_new()
    response = JSONResponse({"status": "ok", "expires_in": int(_ADMIN_SESSION_TTL)})
    response.set_cookie(
        _ADMIN_COOKIE, token,
        max_age=int(_ADMIN_SESSION_TTL),
        httponly=True,           # unreadable from JS — the whole point
        secure=_ADMIN_COOKIE_SECURE,
        samesite="strict",       # never sent on a cross-site request
        path="/",
    )
    return response


@app.post("/admin/logout", tags=["Admin"])
async def admin_logout(request: Request):
    """Revoke this browser's admin session. Idempotent."""
    token = request.cookies.get(_ADMIN_COOKIE, "")
    _admin_sessions.pop(token, None)
    response = JSONResponse({"status": "ok"})
    response.delete_cookie(_ADMIN_COOKIE, path="/")
    return response


@app.post("/admin/intents/sanitize", tags=["Admin"], dependencies=[Depends(require_admin)])
async def sanitize_intent(body: CandidateIntent):
    """Pre-flight checks before onboarding a new intent.

    Returns a structured report listing every encoding issue, pattern
    duplicate, response too-short/too-long, profanity hit, and classifier
    collision (cases where the *current* model would have confidently sent
    one of the new patterns to a different intent — that's a regression
    risk).
    """
    try:
        from intents_db import load_intents as _load_intents
        existing = _load_intents()
    except Exception:
        existing = []

    candidate = body.model_dump()
    report = _sanitize_candidate_intent(
        candidate,
        existing_intents=existing,
        classifier_predict_proba=_predict_proba_dict,
    )
    return report.to_dict()


@app.post("/admin/intents", tags=["Admin"], dependencies=[Depends(require_admin)])
async def create_intent(body: CandidateIntent, force: bool = False):
    """Apply a candidate intent: append to cavsu_intents.json, rebuild the
    SQLite DB, and ask the caller to re-run training to activate it in the
    live model.

    Sanitation is re-run server-side; we refuse on any *error* finding
    unless ?force=true is passed (so the admin can still ship a known
    collision intentionally — e.g. when later renaming an existing intent).
    Warnings don't block. The model is NOT retrained synchronously — that
    would block the API for minutes — the response tells the caller to run
    `python training/train_naive_bayes.py`.
    """
    import json as _json
    from pathlib import Path as _Path
    try:
        from intents_db import load_intents as _load_intents
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Intent database unavailable")

    # Reserved tags are refused UNCONDITIONALLY — ?force=true exists to ship a
    # known pattern collision, never to shadow a code-owned tier or system
    # state (the classifier must not learn to predict "llm_unavailable",
    # "safety_*", the MCP bridge labels, …).
    if _intent_curation_is_reserved(body.tag):
        raise HTTPException(
            status_code=422,
            detail={
                "message": f"'{body.tag}' is a reserved system tag and cannot "
                           "be onboarded, even with force=true.",
                "code": "tag_reserved",
            },
        )

    existing = _load_intents()
    candidate = body.model_dump()
    report = _sanitize_candidate_intent(
        candidate, existing_intents=existing,
        classifier_predict_proba=_predict_proba_dict,
    )
    if report.has_errors and not force:
        raise HTTPException(
            status_code=422,
            detail={
                "message": "Sanitation errors block the write. Fix them or retry with ?force=true.",
                "report": report.to_dict(),
            },
        )

    # Write directly to DB (source of truth)
    try:
        import sqlite3
        db_path = _Path("data/cavsu_intents.db")
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute(
            "INSERT OR IGNORE INTO intents (tag, description, active) VALUES (?, ?, ?)",
            (body.tag, "", 1),
        )
        intent_id = cur.execute(
            "SELECT id FROM intents WHERE tag = ?", (body.tag,)
        ).fetchone()["id"]
        for pattern in body.patterns:
            cur.execute(
                "INSERT INTO patterns (intent_id, pattern_text) VALUES (?, ?)",
                (intent_id, pattern),
            )
        for response in body.responses:
            cur.execute(
                "INSERT INTO responses (intent_id, response_text) VALUES (?, ?)",
                (intent_id, response),
            )
        conn.commit()
        conn.close()
    except Exception as exc:
        _logger.error("DB write failed: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to save intent")

    # Also sync to JSON as a backup export
    json_path = _Path("data/cavsu_intents.json")
    try:
        if json_path.exists():
            raw = _json.loads(json_path.read_text(encoding="utf-8"))
        else:
            raw = {"intents": []}
        raw.setdefault("intents", []).append({
            "tag": body.tag,
            "patterns": body.patterns,
            "responses": body.responses,
        })
        tmp = json_path.with_suffix(json_path.suffix + ".tmp")
        tmp.write_text(_json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(json_path)
    except Exception:
        pass  # JSON backup is best-effort; DB is the source of truth

    return {
        "status": "saved",
        "tag": body.tag,
        "warnings": report.has_warnings,
        "report": report.to_dict(),
        "next_step": (
            "Run `python training/train_naive_bayes.py` and restart the API "
            "to activate this intent for routing."
        ),
    }


# ============================================================================
# Error Handlers
# ============================================================================

# Safe error messages by status code — never leak internals to the client.
_SAFE_ERROR_MESSAGES = {
    400: "Bad request",
    401: "Unauthorized",
    403: "Forbidden",
    404: "Not found",
    422: "Validation error",
    429: "Too many requests",
    500: "Internal server error",
    503: "Service unavailable",
}


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Return generic error messages. Internal details are logged server-side only."""
    # Log full detail for debugging, but never send it to the client
    _logger.warning("HTTP %s on %s: %s", exc.status_code, request.url.path, exc.detail)
    safe_message = _SAFE_ERROR_MESSAGES.get(exc.status_code, "Request failed")
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": True, "message": safe_message},
    )


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Catch-all: log the real error, return a generic 500."""
    _logger.exception("Unhandled exception on %s", request.url.path)
    return JSONResponse(
        status_code=500,
        content={"error": True, "message": "Internal server error"},
    )


# ============================================================================
# Admin surface invariant
# ============================================================================
# ~30 routes carry `dependencies=[Depends(require_admin)]` one by one, which is
# easy to forget on the next route someone adds. This audit runs at import time
# and fails LOUDLY, so an ungated admin route breaks the boot (and CI) instead
# of silently shipping an open endpoint that returns chat logs or PII.
#
# Each entry below is public BY DESIGN — a considered exception, not an
# oversight. Anything else under the admin path policy must carry the gate.
_PUBLIC_BY_DESIGN: set = {
    ("POST", "/admin/verify"),      # the PIN check itself — can't require the PIN
    ("POST", "/admin/logout"),      # revokes the caller's own cookie; must stay
                                    # callable with an expired/absent session so
                                    # signing out never dead-ends
    ("GET", "/admin/logs"),         # static HTML shell, no secrets in it; a browser
                                    # can't attach X-Admin-Pin on a plain navigation
    ("POST", "/feedback"),          # users submit feedback anonymously
    ("GET", "/feedback/reasons"),   # public reason taxonomy the chat UI renders
}


def _route_is_admin_gated(route) -> bool:
    """True when `require_admin` appears anywhere in the route's dependency tree."""
    dependant = getattr(route, "dependant", None)
    if dependant is None:
        return False
    stack = [dependant]
    while stack:
        node = stack.pop()
        if getattr(node, "call", None) is require_admin:
            return True
        stack.extend(getattr(node, "dependencies", []) or [])
    return False


def _requires_admin_by_policy(method: str, path: str) -> bool:
    """Whether (method, path) is part of the protected admin surface."""
    if (method, path) in _PUBLIC_BY_DESIGN:
        return False
    if path.startswith(("/admin", "/logs", "/conversation", "/feedback")):
        return True
    # Operator-only endpoints that don't share a common prefix. Listed so that
    # REMOVING their gate also trips this audit, not just forgetting to add it.
    if path in ("/ais_mcp_stats", "/connectors_mcp_stats", "/model/reload"):
        return True
    if path.startswith("/map"):
        # Map reads are public (the chat renders the campus map); writes are not.
        return method not in ("GET", "HEAD")
    return False


def _audit_admin_surface() -> list:
    """Return 'METHOD /path' for every protected route missing require_admin."""
    gaps = []
    for route in app.routes:
        path = getattr(route, "path", "")
        for method in sorted(getattr(route, "methods", None) or ()):
            if method in ("HEAD", "OPTIONS"):
                continue
            if _requires_admin_by_policy(method, path) and not _route_is_admin_gated(route):
                gaps.append(f"{method} {path}")
    return sorted(set(gaps))


# ── Channel gateways (poc) ──────────────────────────────────────────────────
# Mounted BEFORE the admin-surface audit below runs, so gateway routes are
# audited like every other route. Each gateway is env-gated: with its flag
# unset the router is never mounted and the API surface is byte-for-byte
# unchanged. See api/channels/ and docs/MESSENGER_GATEWAY.md.
from .channels import messenger as _messenger_channel  # noqa: E402

if _messenger_channel.enabled():
    app.include_router(_messenger_channel.router)
    _logger.info("Messenger channel gateway mounted at /channels/messenger")

_ADMIN_SURFACE_GAPS = _audit_admin_surface()
if _ADMIN_SURFACE_GAPS:
    raise RuntimeError(
        "Admin surface invariant violated — these routes expose or mutate "
        "protected data but carry no require_admin dependency:\n  "
        + "\n  ".join(_ADMIN_SURFACE_GAPS)
        + "\n\nAdd `dependencies=[Depends(require_admin)]` to the route, or — if it "
          "is intentionally public — add an explicit entry to _PUBLIC_BY_DESIGN."
    )

# ============================================================================
# Run Server
# ============================================================================
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app:app",
        host="127.0.0.1",
        port=8000,
        reload=False
    )

